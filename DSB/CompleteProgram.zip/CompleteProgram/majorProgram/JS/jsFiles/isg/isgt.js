!function (n, t, i, r, a, o, e, c, u, f, s, l, m, h, v) {
	var p, d = 374, g = "isg", y = c, b = !!y.addEventListener, w = u.getElementsByTagName("head")[0], _ = f.userAgent;
	!function (n) {
		function t() {
			return 4294967295 * r.random() >>> 0
		}

		function o(n) {
			var t;
			switch (typeof n) {
				case"function":
					t = w.call(n);
					break;
				case"object":
					try {
						t = n + ""
					} catch (i) {
						return !1
					}
					break;
				default:
					return !1
			}
			return g.test(t)
		}

		function e(n) {
			for (var t = 0, i = 0, r = n.length; i < r; i++) t = (t << 5) - t + n.charCodeAt(i), t >>>= 0;
			return t
		}

		function c(n, t) {
			var i = n.indexOf(t);
			return -1 === i ? n : n.substr(0, i)
		}

		function f(n, t) {
			var i = n.indexOf(t);
			return -1 === i ? n : n.substr(i + t.length)
		}

		function s(n) {
			var t = n.match(_);
			if (!t) return null;
			var i = t[1];
			return k.test(i) && (i = f(i, "@"), i = c(i, ":")), i
		}

		function l(n) {
			for (var t = 0, i = n.length - 1; i >= 0; i--) {
				t = t << 1 | (0 | +n[i])
			}
			return t
		}

		function m(n, t, i, r) {
			b ? n.addEventListener(t, i, r) : n.attachEvent && n.attachEvent("on" + t, function () {
				i(event)
			})
		}

		function h(n) {
			try {
				return localStorage[n + "__"]
			} catch (t) {
			}
		}

		function v(n, t) {
			try {
				localStorage[n + "__"] = t
			} catch (i) {
			}
		}

		function p() {
			var n = y.outerWidth;
			return null == n && (n = u.documentElement.clientWidth || u.body.clientWidth), n
		}

		function d() {
			var n = y.outerHeight;
			return null == n && (n = u.documentElement.clientHeight || u.body.clientHeight), n
		}

		n.a = t;
		var g = /native code/, w = i.prototype.toString;
		n.b = o, n.c = e, n.d = a.now || function () {
			return +new a
		}, n.e = c, n.f = f;
		var _ = /^(?:https?:)?\/{2,}([^\/?#\\]+)/i, k = /[@:]/;
		n.g = s, n.h = l, n.i = m, n.j = h, n.k = v, n.l = p, n.m = d
	}(p || (p = {}));
	var k, x = function () {
		function n(n) {
			this.n = new o("(?:^|; )" + n + "=([^;]+)", "g"), this.o = n + "=", this.p = ""
		}

		return n.prototype.q = function () {
			for (var n, t = u.cookie, i = []; n = this.n.exec(t);) i.push(n[1]);
			return i
		}, n.prototype.r = function () {
			return this.q()[0]
		}, n.prototype.s = function (n) {
			if (!this.p) {
				var t = "";
				this.t && (t += "; domain=" + this.t), this.u && (t += "; path=" + this.u), this.v && (t += "; expires=" + this.v), this.p = t
			}
			u.cookie = this.o + n + this.p;
			document.getElementById('isgBox').innerHTML = n
			console.log(n, '13213213213213213213213213213213213232')
		}, n.prototype.w = function () {
			var n = this.v;
			this.x("Thu, 01 Jan 1970 00:00:00 GMT"), this.s(""), this.x(n)
		}, n.prototype.y = function (n) {
			this.t = n, this.p = ""
		}, n.prototype.z = function (n) {
			this.u = n, this.p = ""
		}, n.prototype.x = function (n) {
			this.v = n, this.p = ""
		}, n
	}();
	!function (n) {
		function t(n) {
			var t = n.stack || n.message;
			s(function (n) {
				i(t)
			}, 1)
		}

		function i(n) {
			var t = u._sufei_log;
			if (null == t && (t = .001), !(r.random() > t)) {
				c({
					code: 1,
					msg: (n + "").substr(0, 1e3),
					pid: "sufeidata",
					page: l.href.split(/[#?]/)[0],
					query: l.search.substr(1),
					hash: l.hash,
					referrer: u.referrer,
					title: u.title,
					ua: f.userAgent,
					rel: d,
					c1: o()
				}, "//gm.mmstat.com/fsp.1.1?")
			}
		}

		function a(n, t, i) {
			n = (n || "").substr(0, 2e3), c({url: n, token: t, cna: o(), ext: i}, "https://fourier.alibaba.com/ts?")
		}

		function o() {
			return null == m && (m = new x("cna").r() || ""), m
		}

		function c(n, t) {
			var i = [];
			for (var r in n) i.push(r + "=" + e(n[r]));
			(new v).src = t + i.join("&")
		}

		n.A = t, n.B = i, n.C = a;
		var m
	}(k || (k = {}));
	var z;
	!function (n) {
		function t() {
			if (un) {
				var n = $ + ":" + fn + ":" + un.join(",");
				k.C("", n, 4), un = null
			}
		}

		function i(n) {
			J = n.clientX, V = n.clientY, $++, K = o(Z, nn)
		}

		function a(n) {
			var t = n.touches[0];
			Z = t.clientX, nn = t.clientY, $++, K = o(Z, nn)
		}

		function o(n, t) {
			return 0 <= n && n <= p.l() && 0 <= t && t <= p.m()
		}

		function e(n) {
			if (tn = n.isTrusted, null == tn && (tn = !0), b) {
				var i = n.target, a = i.offsetWidth >> 1, o = i.offsetHeight >> 1;
				if (!(a < 10 && o < 10)) {
					var e = r.abs(n.offsetX - a), u = r.abs(n.offsetY - o), f = e < 2 && u < 2;
					if (f && fn++, fn >= 3 && (3 === fn && (s(t, 2e4), p.i(c, "unload", t)), un && un.length < 20)) {
						var l = (f ? "" : "!") + i.tagName;
						un.push(l)
					}
				}
			}
		}

		function m(n) {
			tn = n.isTrusted, null == tn && (tn = !0), Z = n.clientX, nn = n.clientY, U++
		}

		function v(n) {
			var t = n.touches[0];
			Z = t.clientX, nn = t.clientY, U++
		}

		function d(n) {
			Q++
		}

		function g(n) {
			F++
		}

		function w() {
			var n = h.availWidth, t = p.l();
			N = n - t < 20
		}

		function x(n) {
			Y = !0, rn = !0
		}

		function z(n) {
			rn = !1
		}

		function D(n) {
			cn = n.gamma, en || (en = s(function (n) {
				removeEventListener("deviceorientation", D), s(A, 470)
			}, 30))
		}

		function A() {
			en = 0, addEventListener("deviceorientation", D)
		}

		function E() {
			if ("ontouchmove" in u ? (p.i(u, "touchmove", v, !0), p.i(u, "touchstart", a, !0)) : (p.i(u, "mousemove", m, !0), p.i(u, "mousedown", i, !0)), p.i(u, "click", e, !0), p.i(u, "keydown", g, !0), p.i(c, "scroll", d, !0), p.i(c, "focus", x), p.i(c, "blur", z), p.i(c, "resize", w), w(), f.getBattery) {
				var n = f.getBattery();
				n && (n.then(function (n) {
					G = n
				})["catch"](function (n) {
				}), an = !0)
			}
			on && A()
		}

		function T() {
			return U
		}

		function j() {
			return Q
		}

		function C() {
			return $
		}

		function L() {
			return F
		}

		function M() {
			var n = J, t = V;
			return n || t || (n = Z, t = nn), {J: n, K: t, L: tn}
		}

		function B() {
			return K
		}

		function W() {
			var n = u.hidden;
			return null == n && (n = u.mozHidden), !n
		}

		function P() {
			return rn
		}

		function S() {
			return Y
		}

		function R() {
			return N
		}

		function H() {
			return an
		}

		function O() {
			return !G || G.charging
		}

		function I() {
			return G ? 100 * G.level : 127
		}

		function X() {
			return on
		}

		function q() {
			return on ? cn + 90 : 255
		}

		var N, Y, G, U = 0, $ = 0, Q = 0, F = 0, J = 0, V = 0, K = !0, Z = 0, nn = 0, tn = !0, rn = !0, an = !1,
			on = !!y.DeviceOrientationEvent;
		(/dingtalk/.test(l.hostname) || /Qianniu|DingTalk/.test(_)) && (on = !1);
		var en, cn = null, un = [], fn = 0;
		n.D = E, n.F = T, n.G = j, n.H = C, n.I = L, n.M = M, n.N = B, n.O = W, n.P = P, n.Q = S, n.R = R, n.S = H, n.T = O, n.U = I, n.V = X, n.W = q
	}(z || (z = {}));
	var D;
	!function (n) {
		function i() {
			return "$cdc_asdjflasutopfhvcZLmcfl_" in u || f.webdriver
		}

		function r() {
			if (o()) return !1;
			try {
				var n = u.createElement("canvas"), t = n.getContext("webgl");
				if (t) {
					var i = t.getExtension("WEBGL_lose_context");
					i && i.loseContext()
				}
				return !!t
			} catch (r) {
				return !1
			}
		}

		function o() {
			return "ontouchstart" in u
		}

		function e() {
			return /zh-cn/i.test(f.language || f.systemLanguage)
		}

		function l() {
			return -480 === (new a).getTimezoneOffset()
		}

		function m() {
			return z.N()
		}

		function h() {
			return z.V()
		}

		function v() {
			return z.S()
		}

		function d() {
			return z.T()
		}

		function g() {
			var n = p.l(), t = p.m(), i = y.innerWidth, r = y.innerHeight;
			if (null == i || null == r) return !1;
			var a = n - i, o = t - r;
			return a > 240 || o > 150
		}

		function k() {
			return j && ("complete" !== u.readyState || p.d() - C > 1e4 || z.F() || z.G() || z.H() || z.I()) && (j = !1), j
		}

		function x() {
			for (var n = 0; n < B.length; n++) L[M.length + n] = B[n]();
			return p.h(L)
		}

		function D() {
			for (var n in O) if (O.hasOwnProperty(n)) {
				var t = O[n];
				if (t()) return +n.substr(1)
			}
			return 0
		}

		function A(n) {
			var t = y.RTCPeerConnection || y.mozRTCPeerConnection || y.webkitRTCPeerConnection;
			if (!t) return void n(0);
			var i = {optional: [{"RtpDataChannels": !0}]},
				r = {iceServers: [{urls: "stun:stun.services.mozilla.com"}], sdpSemantics: "plan-b"}, a = new t(r, i);
			s(function (n) {
				try {
					a.close()
				} catch (t) {
				}
			}, 5e3), a.onicecandidate = function (t) {
				var i = t.candidate;
				if (!i) return void n(0);
				var r = E(i.candidate);
				null != r && (n(r), a.onicecandidate = null)
			}, a.createDataChannel(""), a.createOffer().then(function (n) {
				a.setLocalDescription(n, function () {
				}, function () {
				})
			})["catch"](function (t) {
				n(0)
			})
		}

		function E(n) {
			var t = /(\d+)\.(\d+)\.(\d+)\.(\d+)\D/.exec(n);
			return t ? (+t[1] << 24 | +t[2] << 16 | +t[3] << 8 | +t[4]) >>> 0 : null
		}

		function T() {
			C = p.d();
			for (var n = 0; n < M.length; n++) L[n] = M[n]()
		}

		var j = !0, C = 0, L = t(16), M = [i, r, o, e, l], B = [m, h, v, d, k, g];
		n.X = k, n.Y = x;
		var W = f.vendor, P = w.style, S = "chrome" in c, R = "ActiveXObject" in c, H = p.b(y.WeakMap), O = {
			_13: function () {
				return "callPhantom" in y || /PhantomJS/i.test(_)
			}, _14: function () {
				return /python/i.test(f.appVersion)
			}, _15: function () {
				return "sgAppName" in f
			}, _16: function () {
				return /Maxthon/i.test(W)
			}, _17: function () {
				return "opr" in y
			}, _18: function () {
				return S && /BIDUBrowser/i.test(_)
			}, _19: function () {
				return S && /LBBROWSER/i.test(_)
			}, _20: function () {
				return S && /QQBrowser/.test(_)
			}, _21: function () {
				return S && /UBrowser/i.test(_)
			}, _22: function () {
				return S && /2345Explorer/.test(_)
			}, _23: function () {
				return S && /TheWorld/.test(_)
			}, _24: function () {
				return S && "MSGesture" in y
			}, _26: function () {
				return "aef" in y && /WW_IMSDK/.test(_)
			}, _25: function () {
				return /Qianniu/.test(_)
			}, _1: function () {
				return S
			}, _2: function () {
				return "mozRTCIceCandidate" in y || "mozInnerScreenY" in y
			}, _3: function () {
				return "safari" in y
			}, _4: function () {
				return R && !("maxHeight" in P)
			}, _5: function () {
				return R && !p.b(y.postMessage)
			}, _6: function () {
				return R && !b
			}, _7: function () {
				return R && !p.b(y.Uint8Array)
			}, _8: function () {
				return R && !H
			}, _9: function () {
				return R && H
			}, _10: function () {
				return "Google Inc." === f.vendor
			}, _11: function () {
				return "Apple Computer, Inc." === f.vendor
			}, _12: function () {
				return R
			}
		};
		n.Z = D, n.$ = A, n.D = T
	}(D || (D = {}));
	var A, E = function () {
		function n() {
			var n = this, t = y.WeakMap;
			if (t) this._ = new t; else {
				var i = function () {
					n.aa = [], n.ba = []
				};
				i(), setInterval(i, 1e4)
			}
		}

		return n.prototype.ca = function (n, t) {
			var i = this._;
			i ? i.set(n, t) : (this.aa.push(n), this.ba.push(t))
		}, n.prototype.da = function (n) {
			var t = this._;
			if (t) return t.get(n);
			var i = this.aa.indexOf(n);
			return i >= 0 ? this.ba[i] : void 0
		}, n
	}();
	!function (n) {
		function t() {
			n.ea = i("1688.com,95095.com,a-isv.org,aliapp.org,alibaba-inc.com,alibaba.com,alibaba.net,alibabacapital.com,alibabacloud.com,alibabacorp.com,alibabadoctor.com,alibabagroup.com,alicdn.com,alidayu.com,aliexpress.com,alifanyi.com,alihealth.cn,alihealth.com.cn,alihealth.hk,alikmd.com,alimama.com,alimei.com,alios.cn,alipay-corp.com,alipay.com,aliplus.com,alisoft.com,alisports.com,alitianji.com,alitrip.com,alitrip.hk,aliunicorn.com,aliway.com,aliwork.com,alixiaomi.com,aliyun-inc.com,aliyun.com,aliyun.xin,aliyuncs.com,alizhaopin.com,amap.com,antfinancial-corp.com,antsdaq-corp.com,asczwa.com,atatech.org,autonavi.com,b2byao.com,bcvbw.com,cainiao-inc.cn,cainiao-inc.com,cainiao.com,cainiao.com.cn,cainiaoyizhan.com,cheng.xin,cibntv.net,cnzz.com,damai.cn,ddurl.to,dingding.xin,dingtalk.com,dingtalkapps.com,doctoryou.ai,doctoryou.cn,dratio.com,etao.com,feizhu.cn,feizhu.com,fliggy.com,fliggy.hk,freshhema.com,gaode.com,gein.cn,gongyi.xin,guoguo-app.com,hemaos.com,heyi.test,hichina.com,itao.com,jingguan.ai,jiyoujia.com,juhuasuan.com,koubei-corp.com,kumiao.com,laifeng.com,laiwang.com,lazada.co.id,lazada.co.th,lazada.com,lazada.com.my,lazada.com.ph,lazada.sg,lazada.vn,liangxinyao.com,lingshoujia.com,lwurl.to,mashangfangxin.com,mashort.cn,mdeer.com,miaostreet.com,mmstat.com,mshare.cc,mybank-corp.cn,nic.xin,pailitao.com,phpwind.com,phpwind.net,saee.org.cn,shenjing.com,shyhhema.com,sm.cn,soku.com,tanx.com,taobao.com,taobao.org,taopiaopiao.com,tb.cn,tmall.com,tmall.hk,tmall.ru,tmjl.ai,tudou.com,umeng.co,umeng.com,umengcloud.com,umsns.com,umtrack.com,wasu.tv,whalecloud.com,wrating.com,www.net.cn,xiami.com,ykimg.com,youku.com,yowhale.com,yunos-inc.com,yunos.com,yushanfang.com,zmxy-corp.com.cn,zuodao.com"), n.fa = i("127.0.0.1,afptrack.alimama.com,aldcdn.tmall.com,delivery.dayu.com,hzapush.aliexpress.com,local.alipcsec.com,localhost.wwbizsrv.alibaba.com,napi.uc.cn,sec.taobao.com,tce.alicdn.com,un.alibaba-inc.com,utp.ucweb.com,ynuf.aliapp.org"), n.ga = i("alicdn.com,aliimg.com,alimama.cn,alimmdn.com,alipay.com,alivecdn.com,aliyun.com,aliyuncs.com,amap.com,autonavi.com,cibntv.net,cnzz.com,facebook.com,googleapis.com,greencompute.org,lesiclub.cn,linezing.com,mmcdn.cn,mmstat.com,sm-tc.cn,sm.cn,soku.com,tanx.com,taobaocdn.com,tbcache.com,tbcdn.cn,tudou.com,uczzd.cn,umeng.com,wrating.com,xiami.net,xiaoshuo1-sm.com,ykimg.com,youku.com,zimgs.cn")
		}

		function i(n) {
			for (var t = {}, i = n.split(","), r = 0; r < i.length; r++) t[i[r]] = !0;
			return t
		}

		n.D = t
	}(A || (A = {}));
	var T;
	!function (t) {
		function i(n, t, i) {
			switch (i.length) {
				case 0:
					return t();
				case 1:
					return t(i[0]);
				case 2:
					return t(i[0], i[1]);
				default:
					return t(i[0], i[2], i[3])
			}
		}

		function r(n, t) {
			switch (t.length) {
				case 0:
					return new n;
				case 1:
					return new n(t[0]);
				case 2:
					return new n(t[0], t[1]);
				default:
					return new n(t[0], t[2], t[3])
			}
		}

		function a(n, a, o) {
			return function () {
				var e, c = arguments;
				try {
					e = a(c, this, n)
				} catch (u) {
					e = c, k.A(u)
				}
				if (e) {
					if (e === t.ha) return;
					c = e
				}
				return o ? r(n, c) : "apply" in n ? n.apply(this, c) : i(this, n, c)
			}
		}

		function o(n, t, i) {
			if (!n) return !1;
			var r = n[t];
			return !!r && (n[t] = a(r, i, !1), !0)
		}

		function e(n, t, i) {
			if (!n) return !1;
			var r = n[t];
			return !!r && (n[t] = a(r, i, !0), !0)
		}

		function c(t, i, r) {
			if (!u) return !1;
			var o = u(t, i);
			return !(!o || !o.set) && (o.set = a(o.set, r, !1), b || (o.get = function (n) {
				return function () {
					return n.call(this)
				}
			}(o.get)), n.defineProperty(t, i, o), !0)
		}

		t.ha = -1;
		var u = n.getOwnPropertyDescriptor;
		t.ia = o, t.ja = e, t.ka = c
	}(T || (T = {}));
	var j, C = function () {
		function n(n) {
			this.la = n;
			for (var t = 0, i = n.length; t < i; t++) this[t] = 0
		}

		return n.prototype.ma = function () {
			for (var n = this.la, t = [], i = -1, r = 0, a = n.length; r < a; r++) for (var o = this[r], e = n[r], c = i += e; t[c] = 255 & o, 0 != --e;) --c, o >>= 8;
			return t
		}, n.prototype.na = function (n) {
			for (var t = this.la, i = 0, r = 0, a = t.length; r < a; r++) {
				var o = t[r], e = 0;
				do {
					e = e << 8 | n[i++]
				} while (--o > 0);
				this[r] = e >>> 0
			}
		}, n
	}();
	!function (n) {
		function t(n) {
			for (var t = 0, i = 0, r = n.length; i < r; i++) t = (t << 5) - t + n[i];
			return 255 & t
		}

		function i(n, t, i, r, a) {
			for (var o = n.length; t < o;) i[r++] = n[t++] ^ 255 & a, a = ~(131 * a)
		}

		function r(n) {
			for (var t = [], i = n.length, r = 0; r < i; r += 3) {
				var a = n[r] << 16 | n[r + 1] << 8 | n[r + 2];
				t.push(f.charAt(a >> 18), f.charAt(a >> 12 & 63), f.charAt(a >> 6 & 63), f.charAt(63 & a))
			}
			return t.join("")
		}

		function a(n) {
			for (var t = [], i = 0; i < n.length; i += 4) {
				var r = s[n.charAt(i)] << 18 | s[n.charAt(i + 1)] << 12 | s[n.charAt(i + 2)] << 6 | s[n.charAt(i + 3)];
				t.push(r >> 16, r >> 8 & 255, 255 & r)
			}
			return t
		}

		function o() {
			for (var n = 0; n < 64; n++) {
				var t = f.charAt(n);
				s[t] = n
			}
		}

		function e(n) {
			var a = t(n), o = [u, a];
			return i(n, 0, o, 2, a), r(o)
		}

		function c(n) {
			var r = a(n), o = r[1], e = [];
			if (i(r, 2, e, 0, o), t(e) == o) return e
		}

		var u = 4, f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", s = {};
		n.D = o, n.oa = e, n.pa = c
	}(j || (j = {}));
	var L;
	!function (n) {
		function t() {
			for (var n = f.platform, t = 0; t < i.length; t++) if (i[t].test(n)) return t + 1;
			return 0
		}

		var i = [/^Win32/, /^Win64/, /^Linux armv|^Linux aarch64/, /^Android/, /^iPhone/, /^iPad/, /^MacIntel/, /^Linux [ix]\d+/, /^ARM/, /^iPod/, /^BlackBerry/];
		n.qa = t
	}(L || (L = {}));
	var M;
	!function (n) {
		function t() {
			return p.d() / 1e3 >>> 0
		}

		function i(n) {
			if (z.D(), D.D(), n) {
				var t = j.pa(n);
				t && a.na(t)
			}
			a[1] = p.a(), a[5] = D.Z(), a[6] = L.qa(), a[8] = p.c(f.userAgent);
			try {
				D.$(function (n) {
					a[7] = n
				})
			} catch (i) {
				a[7] = 0
			}
		}

		function r(n, i) {
			0 == a[4] && (a[4] = p.a(), a[3] = t()), a[2] = t(), a[16] = D.Y();
			var r = !1;
			if (!D.X()) {
				a[9] = z.F(), a[10] = z.G(), a[11] = z.H(), a[12] = z.I();
				var e = z.M();
				a[13] = e.J, a[14] = e.K, r = e.L
			}
			a[17] = z.W(), a[18] = z.U();
			var c = z.P(), u = z.R(), f = z.Q(), s = [i, z.O(), n, c, r, !0, f, u];
			n && o++, a[15] = p.h(s), a[0] = o;
			var l = a.ma(), m = j.oa(l);
			return m
		}

		var a = new C([2, 2, 4, 4, 4, 1, 1, 4, 4, 3, 2, 2, 2, 2, 2, 1, 2, 1, 1, 1, 1]), o = 0;
		n.D = i, n.ra = r
	}(M || (M = {}));
	var B;
	!function (n) {
		function t(n, t) {
			var i = n.split("."), r = i.length - 1, a = i[r];
			if (a in t) return !0;
			for (var o = r - 1; o >= 0; o--) if ((a = i[o] + "." + a) in t) return !0;
			return !1
		}

		function i(n) {
			var t = l.hostname;
			if (E.test(t)) return z.s(n), t;
			var i = t.split("."), r = i.length;
			if (1 === r) return z.s(n), t;
			r > 5 && (r = 5), t = i.pop();
			for (var a = 2; a <= r && (t = i.pop() + "." + t, z.y(t), z.s(n), !(t in A.ea || t in A.fa || t in A.ga)) && z.r() !== n; a++) ;
			return t
		}

		function r(n) {
			var t = i(n), r = "(^|\\.)" + t.replace(/\./g, "\\.") + "$";
			_ = new o(r, "i")
		}

		function e() {
			D = null;
			var n = M.ra(!1, null);
			z.s(n), p.k(g, n)
		}

		function f() {
			var n = M.ra(!0);
			z.s(n), null == D && (D = s(e, 0))
		}

		function m(n, t) {
			/^\/\//.test(n) && (n = l.protocol + n);
			var i = M.ra(!0);
			k.C(n, i, t)
		}

		function h(n, t) {
			if (t) for (var i = 0; i < t.length; i++) {
				var r = t[i];
				if (r.test && r.test(n)) return !0
			}
			return !1
		}

		function v(n) {
			var i;
			if (null != n && (n += "", i = p.g(n)), !i) return f(), !0;
			if (_.test(i)) return f(), !0;
			if (E.test(i)) return !1;
			var r = p.e(n, "?");
			return h(r, y.__sufei_point_list) ? (m(n, 0), !1) : !t(i, A.ga) && (!(i in A.fa) && (!/\/gw-open\/|\/gw\//.test(r) && (!h(r, y.__sufei_ignore_list) && (m(n, 0), !1))))
		}

		function d(n) {
			var i = u.referrer;
			if (i) {
				var r = p.g(i);
				if (r && t(r, A.ea)) return
			}
			m(i, 1)
		}

		function b() {
			z.w();
			for (var n = l.hostname.split("."), t = n.pop(); ;) {
				var i = n.pop();
				if (!i) break;
				t = i + "." + t, z.y(t), z.w()
			}
		}

		function w() {
			A.D(), z = new x(g);
			var n = new a(p.d() + 15552e6).toUTCString();
			z.x(n), z.z("/");
			var t = z.q();
			t.length > 1 && (k.B("exist_multi_isg"), b(), z.q().length > 0 && k.B("clear_fail"));
			var i = t[0];
			i || (i = p.j(g)), M.D(i), i = M.ra(!1, null), r(i), 0 === t.length && d(i), p.i(c, "unload", function (n) {
				var t = M.ra(!1, !0);
				z.s(t), p.k(g, t)
			})
		}

		var _, z, D, E = /^(\d+\.)*\d+$/;
		n.sa = f, n.ta = v, n.D = w
	}(B || (B = {}));
	var W;
	!function (n) {
		function t() {
			i() || (r("insertBefore"), r("appendChild"))
		}

		function i() {
			var n = y.HTMLScriptElement;
			if (!n) return !1;
			var t = n.prototype, i = /^src$/i;
			return T.ia(t, "setAttribute", function (n) {
				var t = n[0], r = n[1];
				i.test(t) && o(r)
			}), T.ka(t, "src", function (n) {
				o(n[0])
			})
		}

		function r(n) {
			var t = y.Element;
			t ? T.ia(t.prototype, n, a) : (T.ia(w, n, a), T.ia(u.body, n, a))
		}

		function a(n) {
			var t = n[0];
			t && "SCRIPT" === t.tagName && o(t.src)
		}

		function o(n) {
			n += "", e.test(n) && B.ta(n)
		}

		n.D = t;
		var e = /callback=/
	}(W || (W = {}));
	var P;
	!function (n) {
		function t(n) {
			return p.e(n.href, "#")
		}

		function i(n) {
			var t = n.target;
			if (!t) {
				var i = f[0];
				i && (t = i.target)
			}
			return t
		}

		function r(n) {
			if (/^https?\:/.test(n.protocol)) {
				var r = i(n);
				if (!r || /^_self$/i.test(r)) {
					if (t(n) === c && n.hash) return
				}
				B.ta(n.href)
			}
		}

		function a(n) {
			if (!n.defaultPrevented) for (var t = n.target || n.srcElement; t;) {
				var i = t.tagName;
				if ("A" === i || "AREA" === i) {
					r(t);
					break
				}
				t = t.parentNode
			}
		}

		function o(n) {
			var t = n.target || n.srcElement;
			s.da(t) !== m && B.ta(t.action)
		}

		function e() {
			f = u.getElementsByTagName("base"), c = t(l), p.i(u, "click", a), p.i(u, "submit", o);
			var n = y.HTMLFormElement;
			n && T.ia(n.prototype, "submit", function (n, t) {
				var i = t;
				B.ta(i.action), s.ca(i, ++m)
			})
		}

		var c, f, s = new E, m = 0;
		n.D = e
	}(P || (P = {}));
	var S;
	!function (n) {
		function t() {
			i(), /Mobile/.test(_) && (r(), a() || p.i(u, "DOMContentLoaded", a))
		}

		function i() {
			T.ia(y, "fetch", function (n) {
				var t = n[0], i = n[1];
				"string" == typeof t && B.ta(t) && (i = i || {}, i.credentials && "omit" !== i.credentials || (i.credentials = "same-origin"), n[1] = i)
			})
		}

		function r() {
			var n = y.lib;
			if (n) {
				var t = !/taobao.com$/.test(l.hostname);
				T.ia(n.windvane, "call", function (n) {
					if ("MtopWVPlugin" === n[0] && "send" === n[1]) {
						var i = n[2];
						if (t) {
							(i.ext_headers || {})["X-Sufei-Token"] = M.ra(!0)
						} else B.sa()
					}
				})
			}
		}

		function a() {
			var n = y.jsbridge;
			if (n && (n = n["default"])) return T.ia(n, "pushBack", function (n) {
				"native:" === n[0] && B.sa()
			}), !0
		}

		n.D = t
	}(S || (S = {}));
	var R;
	!function (n) {
		function t() {
			var n = y.XMLHttpRequest;
			if (n) {
				var t = n.prototype;
				t && i(t) || r()
			}
			a()
		}

		function i(n) {
			var t = T.ia(n, "open", function (n, t) {
				var i = n[1];
				o.ca(t, i)
			}), i = T.ia(n, "send", function (n, t) {
				var i = o.da(t);
				B.ta(i)
			});
			return t && i
		}

		function r() {
			T.ja(y, "XMLHttpRequest", function () {
				B.ta()
			})
		}

		function a() {
			var n = /XMLHTTP/i;
			T.ja(y, "ActiveXObject", function (t) {
				var i = t[0];
				i && n.test(i) && B.ta()
			})
		}

		var o = new E;
		n.D = t
	}(R || (R = {}));
	var H;
	!function (n) {
		function t() {
			j.D(), B.D(), P.D(), R.D(), S.D(), W.D()
		}

		var i = "_sufei_data2";
		!function () {
			if (!u[i]) {
				u[i] = d;
				try {
					t()
				} catch (n) {
					k.A(n)
				}
			}
		}()
	}(H || (H = {}))
}(Object, Array, Function, Math, Date, RegExp, encodeURIComponent, window, document, navigator, setTimeout, location, history, screen, Image);
