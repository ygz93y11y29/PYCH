import zlib
import base64


'''
    ���ڵ���_token�ƽ⣺
'''
print(zlib.decompress(base64.b64decode('eJxVTttugkAQ/Zd9LYFdWOzCG6mtwRatiBQxPgByU67uRilN/71jah+aTHIuc85kvtDZPiCTYIwpkdAlPSMTERnLEyQhwWGjs0fGmKYyVdcllPzzDJWCF5/9KTJ31KAS2Pub4YLeEUqxZGC8l34pmwBVKcwtY0MEFUJ0pqJcr1f5UEZNVza5nLS1wou2U4hG4KahEXgFQaX2oAJ4umN0R/GnHfgdsrzMG2DpfPDWnPI+cx0eb/CGi8XoDKNXDnMvYRerPW1nbt++pOugG+Kw7ls/fFgFS8fx86awqn42tNu6KqOPwfaP1tv4rJEs7DKmeMJdpmN4VLL3CFf4EuSl//Sai3W8wovKmq7izyJE3z/oU2ZU')))
print(zlib.decompress(base64.b64decode('eJxTSs4sqfRMsbU0UstNzMxzTixJTc8vAokYGRqoFeSXpxbZmqoVZ+QXOMMVgnhAlqGxoYmliaWxIVjALzE31fZpf8/TtROezZj/fPa0l0vXgiVCKgtSbQ0NlADQbyhZ')))





