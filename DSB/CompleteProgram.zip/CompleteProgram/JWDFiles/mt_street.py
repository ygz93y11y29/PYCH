import requests
import json
import datetime
import time
import pymssql


# SQL_ELM_DATBASE = "RPT_DB_V3"
# SQL_ELM_USER = "rip_conn"
# SQL_ELM_PASSWORD = "1234QWER!@#$"
# SQL_ELM_HOST = "192.168.9.180"
# SQL_ELM_CHARSET = "utf8"

SQL_ELM_DATBASE = "ODS"
SQL_ELM_USER = "dss"
SQL_ELM_PASSWORD = "1234QWER!@#$"
SQL_ELM_HOST = "172.17.72.18"
SQL_ELM_CHARSET = "utf8"




class SQLSERVER_MT(object):
    '''
        ����ô��ص�sqlserver����
    '''
    def __init__(self):
        self.db = pymssql.connect(database=SQL_ELM_DATBASE, user=SQL_ELM_USER, password=SQL_ELM_PASSWORD, host=SQL_ELM_HOST,
                             charset=SQL_ELM_CHARSET)
        self.cursor = self.db.cursor()

    def select_street_jwd(self):
        '''
                ��ȡ��ȡ�ֵ��Ĳ�����γ��
            :return:
        '''
        try:
            sql = '''select md5key, shopLat, shopLng from app_spider_MTmtinfo where data_insert>'20200302' and md5key not in 
    (
    select distinct md5key from ods_spider_MTmtArea_20200213 where data_insert>'20200305'
    )'''
            self.cursor.execute(sql)
            rows = self.cursor.fetchall()
            return rows
        except:
            pass

    def instart_street(self, data):
        try:
            insert_sql = "INSERT INTO ods_spider_MTmtArea_20200213 (md5key,province,provinceCode,city,cityCode,district,districtCode,street,township,shoplatitude,shoplongitude,data_insert, data_update) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            self.cursor.execute(insert_sql, data)
            self.db.commit()
            print("insert ods_spider_MTmtArea_20200213 susserd !", data)
            return True
        except Exception as error:
            print('---------------------------------------------------------->instart ods_spider_MTmtArea_20200213 error', error)
            return False


def get_jsondata(md5key, shoplatitude, shoplongitude):
    try:

        #url_key = 'a95cd55415afab6002a63b35641f644b'
        #url_key = '252f71952acc8cf6cfaaf4abf0225a72'
        url_key = '8ac22f9c9fe6b2381c095a2858623a20'
        #url_key = '9731ed6178802129d110a8fe2c67ac34'
        #url_key = 'b5c98fc8bce61133ff47cb21df6cf08a'
        #url_key = '5e91e9228923616f1752ed00cef71d47'

        #url_key = '7f4d0fc62c8403aa8c81f4243b48df42'
        #url_key ='7802e92839fb6816d4b32be5997e1e9f'
        #url_key ='41a0d0acb0ab6bb3c993fa36d770ceb0'
        #url_key ='b65ac7bac54ed07220e8d05ab93ad469'
        #url_key='7f4d0fc62c8403aa8c81f4243b48df42'
        #��Ҫ��ַ��Ϣ
        base_url = 'https://restapi.amap.com/v3/geocode/regeo?output=json&location={},{}&key={}'
        #base_url = 'https://restapi.amap.com/v3/geocode/regeo?output=json&location={},{}&key={}'
        header = {
        'user-agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Mobile Safari/537.36',
    }
        url = base_url.format(shoplongitude, shoplatitude , url_key)
        print(url)
        response =  requests.get(url=url, headers = header)
        #print(response.text)
        if 200 == response.status_code:
                jsondate =  json.loads(response.text)
                #print(jsondate)
                regeocode = jsondate.get("regeocode")
                addressComponent = regeocode.get("addressComponent")
                city = str(addressComponent.get("city"))
                cityCode =  str(addressComponent.get("adcode"))
                province = str(addressComponent.get("province"))
                provinceCode = ''
                district = str(addressComponent.get("district"))
                districtCode = str(addressComponent.get('towncode'))
                street = str(addressComponent.get("streetNumber").get("street"))
                township = str(addressComponent.get("township"))
                date_instert = datetime.datetime.now()
                data_update = date_instert
                data = (md5key, province, provinceCode, city, cityCode, district, districtCode, street, township, shoplatitude,shoplongitude, date_instert, data_update)
                #print("---data----",data)
                return  data
    except:
        print("----------------get_jsondata error-")
def get_key_shoplatitude_shoplongitude():
    SQL = SQLSERVER_MT()
    for jwd in SQL.select_street_jwd():
        print(jwd)
        md5key = jwd[0]
        base_shoplatitude = str(jwd[1])
        base_shoplongitude = str(jwd[2])
        shoplatitude =  base_shoplatitude[:2] + '.' + base_shoplatitude[2:]
        shoplongitude = base_shoplongitude[:3] + '.' + base_shoplongitude[3:]
        #print(shoplatitude)
        #print(shoplongitude)
        #shoplatitude = base_shoplatitude
        #shoplongitude = base_shoplongitude
        print(md5key, shoplatitude, shoplongitude)
        data = get_jsondata(md5key, shoplatitude, shoplongitude)
        print(data)
        SQL.instart_street(data)
        time.sleep(0.5)

        break

if __name__ == '__main__':
    get_key_shoplatitude_shoplongitude()