# -*- coding:utf-8 -*-\
import pymssql
import pymssql

SQL_DATABASE = "RPT_DB_V3"
SQL_USER = "rip_conn"
SQL_PASSWORD = "1234QWER!@#$"
SQL_HOST = "192.168.9.180"

class sqlServerClass(object):
    '''
        sqlServer的操作类
    '''
    def __init__(self):
        self.db = pymssql.connect(database=SQL_DATABASE, user=SQL_USER, password=SQL_PASSWORD, host=SQL_HOST,
                             charset="utf8")
        self.cursor = self.db.cursor()

    def select_licenseNoCompare(self):
        '''
            许可证比对数据来源, 用于cfdaPubClass类
        :return:
        '''
        try:
            sql = '''select a.md5key, a.shopName, address, image1, image2 from 
(select * from app_spider_MTmtinfo where data_insert>'20200615') a,
(select * from #temp1) b 
where a.md5key=b. md5key and image1=''
'''
            self.cursor.execute(sql)
            rows = self.cursor.fetchall()
            return rows
        except Exception as error:
            print('select   error !', error)
            return False


    def insert_MTActualLicense(self, data):
        '''
            向MTActualLicense表中插入数据
        :param data: 元组    来之pase.py
        :return:
        '''
        try:
            sql =  "INSERT INTO ods_spider_MTActualLicense_bengbu (poiInfoId, name, licenseNo, legalRepresentative, address, businessAddress, operateType, businessProject, busNet, centralKitchen, collDistr, bulkCooked, licensingAuthority, issuer, supervisoryAuthority, supervisoryadmin, issuanceDate, validDate, licenseStatus, reportingTelephone, data_insert, isSpider) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            self.cursor.execute(sql,data)
            self.db.commit()
            print("insert insert_MTActualLicense success !")
            return True
        except Exception as error:
            print('instert into insert_MTActualLicense  error ', error)
            return False


if __name__ == '__main__':
    SQL = sqlServerClass()
    print(SQL.select_licenseNoCompare())







