//冻结第 1 行

setTimeout(function() {
	//隐藏报表块report0_c的滚动条（此报表块名为report0_c，根据具体情况修改）
	$("div[widgetname=REPORT0_C]").find(".frozen-north")[0].style.overflow = "hidden";
	$("div[widgetname=REPORT0_C]").find(".frozen-center")[0].style.overflow = "hidden";
}, 100);

window.flag2 = true;	
//鼠标悬停，滚动停止  ,	
//模板中存在多个跑马灯报表块时，依次设置为 flag0，flag1，flag2 等
//需保证全局变量各不相同，否则无法实现单个暂停。	
setTimeout(function() {
	$("div[widgetname=REPORT0_C]").find(".frozen-center").mouseover(function() {
		window.flag2 = false;
	});

	//鼠标离开，继续滚动  
	$("div[widgetname=REPORT0_C]").find(".frozen-center").mouseleave(function() {
		window.flag2 = true;
	});

	var old = -1;
	var interval = setInterval(function() {
		if (window.flag2) {
			currentpos2 = $("div[widgetname=REPORT0_C]").find(".frozen-center")[0].scrollTop;
			if (currentpos2 == old) {
				$("div[widgetname=REPORT0_C]").find(".frozen-center")[0].scrollTop = 0;
			} else {
				old = currentpos2;
				//以25ms的速度每次滚动1.5PX  
				$("div[widgetname=REPORT0_C]").find(".frozen-center")[0].scrollTop = currentpos2 + 1.5;
			}
		}
	}, 25);
}, 1000)
