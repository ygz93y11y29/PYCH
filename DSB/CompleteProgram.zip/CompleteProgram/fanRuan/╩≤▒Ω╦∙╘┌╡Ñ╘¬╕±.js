
//单元格
setTimeout(function() {
	//鼠标经过时
	$(".x-table.REPORT0table td").mousemove(function() {
		//所在单元格字体颜色为红色
		$(this).css("color", "red");
		//所在单元格背景为蓝色
		$(this).css("background-color", "blue");
		//所在单元格字体加粗
		$(this).css("font-weight", "bold");
		//所在单元格添加下划线
		$(this).css("text-decoration", "underline");
		//所在行单元格字体:11px  
		$(this).find("td").css("font-size", "11px");
	});
	//鼠标点击时
	$(".x-table.REPORT0table td").mousedown(function() {
		//所在单元格字体颜色为黄色
		$(this).css("color", "yellow");
		//所在单元格背景为黑色
		$(this).css("background-color", "black");
		//所在单元格字体加粗
		$(this).css("font-weight", "bold");
		//所在单元格添加上划线
		$(this).css("text-decoration", "overline");
		//所在行单元格字体:13px  
		$(this).find("td").css("font-size", "13px");
	});
	//鼠标离开
	$(".x-table.REPORT0table td").mouseout(function() {
		//所在单元格字体颜色为黑色
		$(this).css("color", "black");
		//所在单元格背景为白色
		$(this).css("background-color", "white");
		//所在单元格字体正常
		$(this).css("font-weight", "normal");
		//所在单元格无下划线
		$(this).css("text-decoration", "none");
		//所在行单元格字体:9px  
		$(this).find("td").css("font-size", "9px");
	});
}, 100);

//注：如果预览模板不生效，将 setTimeout 的延时时间调大点就行，比如将 100 改成 500。

//整行
setTimeout(function() {
	//鼠标经过时
	$(".x-table.REPORT1table tr").mousemove(function() {
		//单元格所在行字体颜色为红色
		$(this).css("color", "red");
		//单元格所在行背景为蓝色
		$(this).css("background-color", "blue");
		//单元格所在行字体加粗
		$(this).css("font-weight", "bold");
		//单元格所在行添加下划线
		$(this).css("text-decoration", "underline");
		//单元格所在行字体:11px  
		$(this).find("td").css("font-size", "11px");
	});
	//鼠标点击时
	$(".x-table.REPORT1table tr").mousedown(function() {
		//单元格所在行颜色为黄色
		$(this).css("color", "yellow");
		//单元格所在行背景为黑色
		$(this).css("background-color", "black");
		//单元格所在行字体加粗
		$(this).css("font-weight", "bold");
		//单元格所在行添加上划线
		$(this).css("text-decoration", "overline");
		//单元格所在行字体:13px  
		$(this).find("td").css("font-size", "13px");
	});
	//鼠标离开
	$(".x-table.REPORT1table tr").mouseout(function() {
		//单元格所在行字体颜色为黑色
		$(this).css("color", "black");
		//单元格所在行背景为白色
		$(this).css("background-color", "white");
		//单元格所在行字体正常
		$(this).css("font-weight", "normal");
		//单元格所在行无下划线
		$(this).css("text-decoration", "none");
		//单元格所在行字体:9px  
		$(this).find("td").css("font-size", "9px");
	});
}, 100);
