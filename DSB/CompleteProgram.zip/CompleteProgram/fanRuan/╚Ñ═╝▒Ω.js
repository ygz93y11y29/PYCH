//加于body的初始化事件的js中

FR.HtmlLoader.loadingEffect=function(){}



