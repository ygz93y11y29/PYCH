//添加到报表控件的事件中
setTimeout(function() {
	$("div[widgetname=REPORT0]").find("#frozen-north")[0].style.overflow = "hidden";
	$("div[widgetname=REPORT0]").find("#frozen-center")[0].style.overflow = "hidden";
}, 100);
//隐藏报表块report0的滚动条
window.flag = true;
setTimeout(function() {
	$("#frozen-center").mouseover(function() {
		window.flag = false;
	})
	//鼠标悬停，滚动停止
	$("#frozen-center").mouseleave(function() {
		window.flag = true;
	})
	//鼠标离开，继续滚动
	var old = -1;
	var interval = setInterval(function() {
		if (window.flag) {
			currentpos = $("#frozen-center")[0].scrollTop;
			if (currentpos == old) {
				$("#frozen-center")[0].scrollTop = 0;
			} else {
				old = currentpos;
				$("#frozen-center")[0].scrollTop = currentpos + 1.5;
			}
		}
	}, 25);
	//以25ms的速度每次滚动3.5PX
}, 1000)




