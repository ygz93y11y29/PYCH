


this.options.form.getWidgetByName('report0').setVisible(false);  //隐藏报表块
//注：report0 是报表块名，如果是需要隐藏图表块，换成图表块名即可。


this.options.form.getWidgetByName('report0').setVisible(true); //显示报表块
//注：上述点击事件的写法，只适用于按钮控件在 body 内，当按钮控件在参数面板内时，需要使用另外一种写法，如下：
_g().getWidgetByName('report0').visible(); //显示
_g().getWidgetByName('report0').invisible(); //隐藏

















