import time,os

while True:
    timeStamp = time.time()
    timeArray = time.localtime(timeStamp)
    otherStyleTime = time.strftime("%Y%m%d", timeArray)
    cmd = "nohup scrapy crawl wangyXQ_spider >wangyXQ_spider{}.log &".format(otherStyleTime)
    os.system(cmd)
    time.sleep(43200)


