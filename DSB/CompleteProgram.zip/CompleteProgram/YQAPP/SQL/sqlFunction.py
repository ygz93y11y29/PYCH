import pymssql
import hashlib
import datetime
from YQAPP.setting import SQL_DATBASE, SQL_PASSWORD, SQL_CHARSET, SQL_HOST, SQL_USER


class SQLSERVER(object):
    '''
        饿了么相关的sqlserver操作
    '''
    def __init__(self):
        self.db = pymssql.connect(database=SQL_DATBASE, user=SQL_USER, password=SQL_PASSWORD, host=SQL_HOST,
                             charset=SQL_CHARSET)
        self.cursor = self.db.cursor()

    def insert_app_spider_YQsina(self, data):
        '''
            插入商店信息
        :param data: 解析到的商店信息
        :return:
        '''
        try:
            insert_sql = "INSERT INTO app_spider_YQsina (mtime, allgntotal, alldeathtotal, allsustotal, allcuretotal, addcon, addsus, adddeath, addcure, wjw_addsus, name, ename, cureNum, deathNum, susNum, value, CmapName, Cname, CconNum, CcureNum, CdeathNum, CsusNum, data_insert) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            #data = (mtime, allgntotal, alldeathtotal, allsustotal, allcuretotal, addcon, addsus, adddeath, addcure, wjw_addsus, name, ename, cureNum, deathNum, susNum, value, CmapName, Cname, CconNum, CcureNum, CdeathNum, CsusNum, data_insert)
            self.cursor.execute(insert_sql, data)
            self.db.commit()
            return True
        except Exception as error:
            print('insert_app_spider_YQsina error', error)
            return False

    def insert_app_spider_YQwangY(self, data):
        '''
            插入商店信息
        :param data: 解析到的商店信息
        :return:
        '''
        try:
            insert_sql = "INSERT INTO app_spider_YQwangY (update_timestamp, province, city, district, county, street, community, show_address, full_address, lng, lat, cnt_sum_certain, data_insert) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            self.cursor.execute(insert_sql, data)
            self.db.commit()
            return True
        except Exception as error:
            print('insert_app_spider_YQwangY     error      !', error)
            return False



    def select_text(self):
            '''
                获取爬取街道的参数经纬度
            :return:
            '''
            try:
                sql = ''''''
                self.cursor.execute(sql)
                rows = self.cursor.fetchall()
                return rows
            except:
                pass

if __name__ == '__main__':
    SQL = SQLSERVER()
    data = ('11', '72528', '1870', '6242', '12561', '1897', '0', '99', '2104', '1432', '宁夏', 'ningxia', '42', '0', '0', '70', '固原市', '固原', '5', '3', '0', '0', datetime.datetime.now())

    SQL.insert_app_spider_YQsina(data)