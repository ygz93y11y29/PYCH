import requests
import re
import json
import datetime
import time
import random
from YQAPP.SQL.sqlFunction import SQLSERVER


class wangyClass(object):
    def __init__(self):
        self.SQL = SQLSERVER()

    def req_cityData(self):
        try:
            cityCityList = []
            cityList = []
            timeStamp = time.time()
            timeArray = time.localtime(timeStamp)
            otherStyleTime = time.strftime("%Y%m%d%H%M", timeArray)
            url = "https://spider.ws.126.net/disease_map_data_v2/position?t={}&name=jQuery_disease_community_position&callback=jQuery_disease_community_position".format(otherStyleTime)
            payload = {}
            headers = {
              'accept': '*/*',
              'referer': 'https://wp.m.163.com/163/html/frontend/2019-nCoV-tool-community/index.html?_nw_=1&_anw_=1&spss=epidemic',
              'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36'
            }
            response = requests.request("GET", url, headers=headers, data = payload, allow_redirects = False)
            #print(response.text)
            dictData = re.findall(r'jQuery_disease_community_position\((.*?)\)',response.text)
            if len(dictData) == 1:
                jsonDataStr = dictData[0]
                jsonData = json.loads(jsonDataStr)
                update_timestamp = jsonData.get("update_timestamp_readable")
                dataData = jsonData.get("data")
                keysList = dataData.keys()
                for province in keysList:
                    provinceData = dataData.get(province)
                    cityKeysList = provinceData.keys()
                    for cityCity in cityKeysList:
                        citySing = provinceData.get(cityCity)
                        CityData = (update_timestamp, province, cityCity, citySing)
                        print('CityData:', CityData)
                        cityCityList.append(citySing)
                        cityList.append(cityCity)
            print(len(cityList), cityList)
            return tuple(cityCityList)
        except Exception as error:
            print("/*******************************************/")
            print("error :              req_cityData  error ! ", error)
            print("/*******************************************/")
            return False


    def req_xiaoqData(self, newTime, key):
        try:
            #key = '623cb760da643b448af7f4202a97d1b8'
            url = "https://spider.ws.126.net/disease_map_data_v2/data_{}?t={}&name=jQuery{}&callback=jQuery{}".format(key, newTime, key, key)
            payload = {}
            headers = {
                'referer': 'https://wp.m.163.com/163/html/frontend/2019-nCoV-tool-community/index.html?_nw_=1&_anw_=1&spss=epidemic',
                'accept': '*/*',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36'
            }
            response = requests.get(url, headers=headers, data=payload)
            #print(response.text)
            dataStrList = re.findall('\(\{(.*?)\}\)', response.text)
            dataStr = '{' + dataStrList[0] + '}'
            #print(dataStr)
            jsonData = json.loads(dataStr)
            #print(jsonData)
            update_timestamp = jsonData.get("update_timestamp_readable")
            #print(update_timestamp)
            dataAll = jsonData.get("data")
            #print("dataAll:",    dataAll)
            Ckeys = dataAll.keys()
            for Ckey in Ckeys:
                Cdata1= dataAll.get(Ckey)
                #print("Cdata1:",   Cdata1)
                Ckeys2 = Cdata1.keys()
                #print("Ckeys2:",   Ckeys2)
                for Ckey2 in Ckeys2:
                    city2Data = Cdata1.get(Ckey2)
                    #print(city2Data)
                    cityKeys2 = city2Data.keys()
                    for cityKey in cityKeys2:
                        xqList = city2Data.get(cityKey)
                        for xqData in xqList:
                            province = xqData.get("province")
                            city = xqData.get("city")
                            district = xqData.get("district")
                            county = xqData.get("county")
                            street = xqData.get("street")
                            community = xqData.get("community")
                            show_address = xqData.get("show_address")
                            full_address = xqData.get("full_address")
                            lng = xqData.get("lng")
                            lat = xqData.get("lat")
                            cnt_sum_certain = xqData.get("cnt_sum_certain")
                            data_insert = datetime.datetime.now()
                            data = (update_timestamp, province, city, district, county, street, community, show_address, full_address, lng, lat, cnt_sum_certain, data_insert)
                            print(data)
                            self.SQL.insert_app_spider_YQwangY(data)
            return True
        except Exception as error:
            print("/*******************************************/")
            print("error :              req_xiaoqData             error ! ",error)
            print("/*******************************************/")
            return False
    def get_time(self):
        timeStamp = time.time()
        timeArray = time.localtime(timeStamp)
        otherStyleTime = time.strftime("%Y%m%d%H%M", timeArray)
        return otherStyleTime

    def run(self):
        keyList = list(self.req_cityData())
        print("len(keyList):    {}".format(len(keyList)), keyList)
        #for key in keyList:
            #key = 'fefc3b1a9495aaadbbce95ee6c8afa4b'
            #newTime = self.get_time()
            #print(key, newTime)
            #self.req_xiaoqData(newTime, key)
            #time.sleep(random.randint(5, 15))
        '''
        while True:
            print("len(keyList):    {}".format(len(keyList)))
            if len(keyList) == 0:
                break
            key = keyList.pop()
            print(key)
            
            newTime = self.get_time()
            print(key, newTime)
            if self.req_xiaoqData(newTime, key) == False:
                keyList.append(key)
                time.sleep(300)
            time.sleep(random.randint(5, 15))
        '''
if __name__ == '__main__':
    SPIDER = wangyClass()
    SPIDER.run()


