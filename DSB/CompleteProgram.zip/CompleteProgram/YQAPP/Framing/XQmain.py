import time,os
def re_exe(cmd,inc = 3600):
    while True:
        #time.sleep(inc)
        os.system(cmd)
        time.sleep(inc)

re_exe("python wangyQ_spider.py",43200)
