import time


list1 = [1,2,3,4,5]

print(list1.pop())
print(list1.append(5))
print(list1)
while True:
    i = list1.pop()
    if len(list1)==0:
        break
    print(i)
    time.sleep(1)
