# -*- coding:utf-8 -*-
import redis
import time
from elmPoolFiles.config import REDIS_HOST, REDIS_PORT, REDIS_PASSWORD, REDIS_DB

class redisClass():
    '''
        redis类
    '''
    def __init__(self):
        '''
            初始化redis数据库
        '''
        self.r = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD, decode_responses=True, db=REDIS_DB)
        #self.r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD, decode_responses=True, db='13')

    def isgAdd(self, isg):
        '''
            添加isg到redis数据库
        :param isg: isg值
        :return:
        '''
        score = int(time.time())
        self.r.zadd("isgPool", score, isg)

    def isgDelect(self):
        '''
            删除isgPool的数据
        :return:
        '''
        max = int(time.time())
        self.r.zremrangebyrank(name='isgPool', min=0, max=max)

    def isgCount(self):
        '''
            在isgPoolz中isg的数量
        :return:
        '''
        return self.r.zcard("isgPool")

    def isgGet(self):
        '''
            向isgPool中获取最新的isg
        :return: 无返回'', 有返回isg值
        '''
        # start= time.time()-100
        # end = time.time()
        #isgList = self.r.zrevrangebyscore("isgPool",end, start)
        isgList = self.r.zrevrange('isgPool', 0, 1, withscores=False)
        if len(isgList) > 0:
            return isgList[0]
        else:
            return ''


    def xuabAdd(self, xuab):
        '''
            向xuabPool中添加xuab值
        :param xuab: xuab值
        :return:
        '''
        score = int(time.time())
        self.r.zadd("xuabPool", score, xuab)

    def xuabDelect(self):
        '''
            删除xuabPool池中的所有
        :return:
        '''
        max = int(time.time())
        self.r.zremrangebyrank(name='xuabPool', min=0, max=max)

    def xuabCount(self):
        '''
            参训xuabPoolchi中的xuab量
        :return:
        '''
        return self.r.zcard("xuabPool")

    def xuabGet(self):
        '''
            获取最新的xuab
        :return: 无返回'', 有返回xuab值
        '''
        # start= time.time()-100
        # end = time.time()
        xuabList = self.r.zrevrange('xuabPool', 0, 1, withscores=False)
        if len(xuabList) > 0:
            return xuabList[0]
        else:
            return ''









# if __name__ == '__main__':
#     REDIS = redisClass()
#     print(REDIS.isgGet())




