# -- coding: UTF-8 --
import os
import time
import sys
import datetime

print(sys.path)
def main1():
    opt = str(sys.argv[-1])

    print(opt)
    if opt== 'isg':
        os.system("python elmPool.py isg")
    elif opt == 'xuab':
        os.system("python elmPool.py xuab")
    else:
        print('参数错误！')

if __name__ == '__main__':
    import sys
    import os
    curPath = os.path.abspath(os.path.dirname(__file__))
    rootPath = os.path.split(curPath)[0]
    sys.path.append(rootPath)

    main1()