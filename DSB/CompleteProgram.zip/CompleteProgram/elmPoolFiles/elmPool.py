# -*- coding:utf-8 -*-
import os
import sys
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from elmPoolFiles.redisClass import redisClass
import time



class IsgClass():
    def __init__(self, poType):
        self.poType = poType
        self.RE = redisClass()
        self.browser = ''
        self.url = ''

    def creatChrom(self):
        '''
            创建chrom无头浏览器
        :return:
        '''
        chrome_options = Options()
        # chrome_options.add_argument('--headless')
        self.browser = webdriver.Chrome(options=chrome_options, executable_path="D:\doc\chromfile\chromfile\chromedriver.exe")
        if self.poType  == 'isg':
            self.url = 'http://192.168.10.3:5000/elm/isg'
        if self.poType =='xuab':
            self.url = 'http://192.168.10.3:5000/elm/xuab'

    def creatIsg(self):
        '''
            获取isg值
        :return:
        '''
        self.browser.get(self.url)
        if self.poType == 'isg':
            values = self.browser.find_elements_by_id('isgBox')
        elif self.poType =='xuab':
            values = self.browser.find_elements_by_id('x_uab')
        else:
            values = []
        if len(values)==0:
            return False
        value = values[0].text
        return value

    def run(self):
        '''
            获取多个isg值
        :return:
        '''
        self.creatChrom()
        while True:
            value = self.creatIsg()
            # print('{}:{}'.format(self.poType, value))
            if self.poType == 'isg':
                self.RE.isgAdd(value)
            elif self.poType == 'xuab':
                self.RE.xuabAdd(value)
            else:
                values = []
            time.sleep(5)

    def close(self):
        '''
            关闭  webdriver
        :return:
        '''
        self.browser.close()

    def clear(self):
        '''
            清空redis的isg池，和xuab池
        :return:
        '''
        self.RE.isgDelect()
        self.RE.xuabDelect()

if __name__ == '__main__':
    # print('*****')
    opt = str(sys.argv[1])
    ISG = IsgClass(opt)
    ISG.run()
    ISG.close()













