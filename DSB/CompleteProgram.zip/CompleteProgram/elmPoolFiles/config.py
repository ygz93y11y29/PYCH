# -*- coding:utf-8 -*-



'''
    redis配置项
'''
REDIS_HOST = '192.168.10.3'
REDIS_PORT = '6379'
REDIS_PASSWORD = '123456'
REDIS_DB = '2'






