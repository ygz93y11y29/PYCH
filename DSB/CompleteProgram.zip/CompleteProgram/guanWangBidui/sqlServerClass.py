import pymssql
from guanWangBidui.setting import CFDAPUB_SPIDER_sql, SQL_PASSWORD, SQL_DATABASE, SQL_HOST, SQL_USER


class sqlServerClass(object):
    '''
        sqlServer的操作类
    '''
    def __init__(self):
        self.db = pymssql.connect(database=SQL_DATABASE, user=SQL_USER, password=SQL_PASSWORD, host=SQL_HOST,
                             charset="utf8")
        self.cursor = self.db.cursor()

    def select_licenseNoCompare(self):
        '''
            许可证比对数据来源, 用于cfdaPubClass类
        :return:
        '''
        try:
            sql = CFDAPUB_SPIDER_sql
            self.cursor.execute(sql)
            rows = self.cursor.fetchall()
            print("select_licenseNoCompare success !")
            if len(rows) == 0:
                print("select_licenseNoCompare rows = 0")
                return False
            else:
                return rows
        except Exception as error:
            print('select_licenseNoCompare error !', error)
            return False


    def insert_MTActualLicense(self, data):
        '''
            向MTActualLicense表中插入数据
        :param data: 元组    来之pase.py
        :return:
        '''
        try:
            sql =  "INSERT INTO ods_spider_MTActualLicense_bengbu (poiInfoId, name, licenseNo, legalRepresentative, address, businessAddress, operateType, businessProject, busNet, centralKitchen, collDistr, bulkCooked, licensingAuthority, issuer, supervisoryAuthority, supervisoryadmin, issuanceDate, validDate, licenseStatus, reportingTelephone, data_insert, isSpider) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            self.cursor.execute(sql,data)
            self.db.commit()
            print("insert insert_MTActualLicense success !")
            return True
        except Exception as error:
            print('instert into insert_MTActualLicense  error ', error)
            return False


if __name__ == '__main__':
    SQL = sqlServerClass()
    licenseNoCompareList = SQL.select_licenseNoCompare()
    print(licenseNoCompareList)
    print(len(licenseNoCompareList))
