from lxml import etree
from guanWangBidui.redisClass import RedisClass
#from pase_supplement import dict_tuple_paseSmszk, get_md5
from guanWangBidui.sqlServerClass import sqlServerClass
import datetime


class paseClass(object):
    def __init__(self):
        self.REDIS = RedisClass()
        self.SQL = sqlServerClass()

    def dict_tuple_paseSmszk(self, item):
        try:

            poiInfoId = item.get("poiInfoId")
            name = item.get("经营者名称")
            licenseNo = item.get("许可证编号")
            legalRepresentative = item.get("法定代表人(负责人)")
            address = item.get("住所")
            businessAddress = item.get("经营场所")
            operateType = item.get("主体业态")
            businessProject = item.get("经营项目")
            busNet = item.get("网络经营")
            centralKitchen = item.get("中央厨房")
            collDistr = item.get("集体用餐配送单位")
            bulkCooked = item.get("散装熟食销售")
            licensingAuthority = item.get("发证机关")
            issuer = item.get("签发人")
            supervisoryAuthority = item.get("日常监督管理机构")
            supervisoryadmin = item.get("日常监督管理人员")
            issuanceDate = item.get("发证日期")
            validDate = item.get("有效期至")
            licenseStatus = item.get("许可证状态")
            reportingTelephone = item.get("监督举报电话")
            data_insert = datetime.datetime.now()
            isSpider = 1
            data = (
            str(poiInfoId), str(name), str(licenseNo), str(legalRepresentative), str(address), str(businessAddress),
            str(operateType), str(businessProject), str(busNet), str(centralKitchen), str(collDistr), str(bulkCooked),
            str(licensingAuthority), str(issuer), str(supervisoryAuthority), str(supervisoryadmin), str(issuanceDate),
            str(validDate), str(licenseStatus), str(reportingTelephone), data_insert, isSpider)
            return data
        except:
            print("dict_tuple_paseSmszk error !")
            return False

    def pase_cfdaPub(self, response, poiInfoId):
        '''
            解析http://118.26.25.129:8098/cfdaPub/pub!view.网页  许可证比对
        :param response:	请求返回的text
        :param poiInfoId:	商店的
        :return:
        '''
        dom = etree.HTML(response)
        trList = dom.xpath('//div[@id="jibenxinxi"]/table/tr')
        singPdflibr = {}
        singPdflibr['poiInfoId'] = poiInfoId
        for tr in trList:
            ths = tr.xpath('./th/text()')
            tds = tr.xpath('./td/text()')
            if len(ths) == 2:
                if len(tds) == 2:
                    td = tds
                else:
                    td = ["", ""]
                singPdflibr[ths[0].strip().strip(':')] = td[0].strip()
                singPdflibr[ths[1].strip().strip(':')] = td[1].strip()
            if len(ths) == 1:
                if len(tds) == 0:
                    td = [""]
                else:
                    td = tds
                singPdflibr[ths[0].strip().strip(':')] = td[0].strip()
        if singPdflibr.get("许可证编号") == '':
            print("poiInfoId: {}; {}".format(poiInfoId, response))
            self.REDIS.add_cfdaPub(poiInfoId)
            return True
        data = self.dict_tuple_paseSmszk(singPdflibr)
        print(data)
        if self.REDIS.exit_cfdaPub(poiInfoId) == False:
            sign = self.SQL.insert_MTActualLicense(data)
            if sign == True:
                self.REDIS.add_cfdaPub(poiInfoId)
        return True