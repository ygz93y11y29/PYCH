import requests
from lxml import etree



url ='http://spjyxk.gsxt.gov.cn/cfdaPub/main.jsp'

headers = {
    'User-Agen':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
    'Host':'spjyxk.gsxt.gov.cn',
    'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
}
#response = requests.get(url)
#print(response.text)
#html = etree.HTML(response.text)


parser = etree.HTMLParser(encoding="utf-8")
htmlelement = etree.parse("./htmlFile/main_jsp.html", parser=parser)
#html = etree.tostring(htmlelement, encoding="utf-8").decode("utf-8")

optionList = htmlelement.xpath('//select[@id="deptCode"]/option')
deptDict = {}
for option in optionList:
    deptCode = option.xpath('./@value')[0]
    deptName = option.xpath('./text()')[0]
    deptDict[deptName]=deptCode

print(deptDict)


print(deptDict.get('北京')==None)

