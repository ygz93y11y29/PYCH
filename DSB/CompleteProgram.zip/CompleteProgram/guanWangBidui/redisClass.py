import redis
from guanWangBidui.setting import REDIS_DB, REDIS_HOST, REDIS_PASSWORD, REDIS_PORT

class RedisClass(object):
    def __init__(self):
        self.r = redis.Redis(host=REDIS_HOST,
                               port=REDIS_PORT,
                               password=REDIS_PASSWORD,
                               decode_responses=True,   # decode_responses=True，写入value中为str类型，否则为字节型
                               db=REDIS_DB)                  # 默认不写是db0

    def add_phone(self,value):
        '''
            向 phoneStr 插入数据
        '''
        self.r.sadd('phoneStr',value)

    def get_num(self):
        '''
            查询phoneStr 电话号个数
        '''
        return self.r.scard("phoneStr")

    def exit(self,value):
        '''
            查看电话号字符串是否存在
        :param value:
        :return:
        '''
        return  self.r.sismember("phoneStr",value)
    def get_phone(self):
        '''
            获得没有使用过的电话号
        :return:
        '''
        phoneSet1 = self.r.sdiff('phoneStr', "phoneStr_ing")
        return phoneSet1

    def add_phoneing(self,value):
        '''
            向 phoneStr_ing 插入数据，已使用获得电话号
        '''
        self.r.sadd('phoneStr_ing',value)

    def add_cfdaPub(self, value):
        '''
            向cfdaPub 插入数据，用于cfdaPub_spider去重
        :return:
        '''
        self.r.sadd('cfdaPub', value)

    def exit_cfdaPub(self,value):
        '''
            判断是否许可证验证过
        :param value:
        :return:
        '''
        return  self.r.sismember("cfdaPub",value)

    def get_all_cfdaPub(self):
        return self.r.sdiff('cfdaPub')

    def get_frozenPhone(self):
        '''
            获取冻结的电话号码
        :return:
        '''
        return self.r.sdiff('frozenPhone')

    def add_ShopKey(self, key):
        '''
            插入爬过的数据， 用于elmShop_spider
        :param key:
        :return:
        '''
        self.r.sadd('md5key', key)

    def exit_ShopKey(self,value):
        '''
            判断是否许爬过，用于elmShop_spider
        :param value:
        :return:
        '''
        return  self.r.sismember("md5key",value)

    def add_batcParame(self, key):
        '''
            插入爬过的数据， 用于batch_spider
        :param key:
        :return:
        '''
        self.r.sadd('elmshop_bachShopnew', key)


    def add_batchKey(self, key):
        '''
            插入爬过的数据， 用于batch_spider
        :param key:
        :return:
        '''
        self.r.sadd('batchKey', key)

    def exit_batchKey(self,value):
        '''
            判断是否许爬过，用于batch_spider
        :param value:
        :return:
        '''
        return  self.r.sismember("batchKey",value)

    def get_batcParame(self):
        '''
            获取batch_spider url 所需要的参数
        :return:
        '''
        pass

    def add_commentKey(self, key):
        '''
            插入爬过的商店评论， 用于elmShop_spider,
        :param key:
        :return:
        '''
        self.r.sadd('commentKey', key)

    def get_commentParame_all(self):
        '''
            获取elmComment_spider uel参数
        :return: set，各个url的参数set
        '''
        commentParameSet = self.r.sdiff('commentKey', "commentKey_ing")
        return commentParameSet


if __name__ == '__main__':
    REDIS = RedisClass()
    print(list(REDIS.get_all_cfdaPub()))
