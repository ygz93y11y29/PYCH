import requests
from guanWangBidui.pase import paseClass
from guanWangBidui.sqlServerClass import sqlServerClass
from guanWangBidui.setting import AREACODEDICT

class cfdaPubClass(object):
    def __init__(self):
        self.PASE = paseClass()
        self.SQL = sqlServerClass()

    def req_cfdaPub(self, licenseKey, areaCode, poiInfoId):
        '''
            爬取http://118.26.25.129:8098/cfdaPub/pub!view.do 的许可证明信息
        :param page:
        :return:
        '''
        basurl = 'http://118.26.25.129:8098/cfdaPub/pub!view.do'
        basurl = 'http://spjyxk.gsxt.gov.cn/cfdaPub/pub!view.do'
        data = {'xkzbh': '{}'.format(licenseKey),
                'areaCode': '{}'.format(areaCode)}
        headers = {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
                'Cookie':'JSESSIONID=2A50B047F3E2DF7130194F3076DB6D67; session_authcode=4',
                "Host": "spjyxk.gsxt.gov.cn",
                "Origin": "http://spjyxk.gsxt.gov.cn",
                "Proxy-Connection": "keep-alive",
                "Referer": "http://spjyxk.gsxt.gov.cn/cfdaPub/pub!list.do"
            }
        try:
            response = requests.post(url=basurl, headers=headers, data=data, timeout=5)
            if response.status_code == 200:
                self.PASE.pase_cfdaPub(response.text, poiInfoId)
                return True
            else:
                return False
        except Exception as error:
            print("<-----req_pdflibr error----->", error)
            return False

    def run(self):
        licenseNoCompareList = self.SQL.select_licenseNoCompare()
        print("len(licenseNoCompareList)    :   ",len(licenseNoCompareList))

        if licenseNoCompareList != False:
            for licenseNoCompare in licenseNoCompareList:
                poiInfoId = licenseNoCompare[0]
                licenseKey = licenseNoCompare[1][:16]
                areaCodestr = licenseNoCompare[2][:3]

                areaCodeDict = AREACODEDICT
                areaCode = areaCodeDict.get(areaCodestr)
                if areaCode != None:
                    if self.req_cfdaPub(licenseKey, areaCode, poiInfoId) ==False:
                        break


if __name__ == '__main__':
    PHONE = cfdaPubClass()
    PHONE.run()


