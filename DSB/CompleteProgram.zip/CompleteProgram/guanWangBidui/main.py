from guanWangBidui.guanWangBiDui_spider import cfdaPubClass

PHONE = cfdaPubClass()
PHONE.run()






