
##############

不能用的时候更新以下内容

######

owl 文件 438 行断点进入 VM***文件
当前版本：1.7.11

VM文件 即是CreateAes.js(ajax全局拦截)

CreateAes.js作为请求拦截
    
238行函数 v( )                          不定期更新





######

95-118行                                不定期更新

AesAlgorithm.js 为AES加密算法           不定期更新

X-FOR-WITH 文件中的 mieta id="wpmTAE"   每天更新

只要更新了mieta  AesAlgorithm.js最后一行 388 行的参数也要做对应的调整
