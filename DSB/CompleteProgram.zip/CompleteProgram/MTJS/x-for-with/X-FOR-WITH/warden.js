!function(e, t) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : e.warden = t()
}(this, function() {
    "use strict";
    var e = function(e) {
        return "none" == e.style.display || (!!function(e) {
            if (0 == (0,
                window.getComputedStyle)(e).opacity)
                return !0;
            return !1
        }(e) || (!!function(e) {
            var t = getComputedStyle(e)
                , n = t.clip;
            if ("absolute" === t.position || "fixed" === t.postion) {
                var r = /rect\(([\s\S]+)\)/.exec(n);
                if (!r || !r[1])
                    return !1;
                var o = r[1]
                    , i = o.split(" ");
                if (parseInt(i[0]) >= parseInt(i[2]) || parseInt(i[1]) <= parseInt(i[3]))
                    return !0
            }
            return !1
        }(e) || !(!function(e) {
            var t = e.getBoundingClientRect()
                , n = t.left
                , r = t.top
                , o = t.right
                , i = t.bottom
                , a = void 0
                , c = void 0;
            if (c = window.innerWidth,
                a = window.innerHeight,
            o < 0)
                return !0;
            if (i < 0)
                return !0;
            if (n > c)
                return !0;
            if (r > a)
                return !0;
            return !1
        }(e) || function(e) {
            return "html" == e.nodeName.toLocaleLowerCase()
        }(e) || function(e) {
            return "body" == e.nodeName.toLocaleLowerCase()
        }(e))))
    };
    var t = function(e, t) {
        return {
            left: Math.max(e.left, t.left),
            right: Math.min(e.right, t.right),
            top: Math.max(e.top, t.top),
            bottom: Math.min(e.bottom, t.bottom)
        }
    }
        , n = function(e) {
        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null
            , r = function() {
            var e = {
                left: 0,
                top: 0,
                right: window.innerWidth,
                height: window.innerHeight
            }
                , t = Object.create(null);
            return t.basicRect = e,
                t.sharpRect = e,
                t
        }()
            , o = window.getComputedStyle
            , i = e.getBoundingClientRect()
            , a = o(e).position
            , c = o(e).overflow;
        return "fixed" == a ? r : (n && (r.basicRect = n.basicRect,
            r.sharpRect = n.sharpRect),
            "visible" == c ? "absolute" == a && (r.basicRect = r.sharpRect) : "static" == a ? r.basicRect = t(r.basicRect, i) : "relative" == a ? (r.sharpRect = t(r.basicRect, i),
                r.basicRect = t(r.sharpRect, r.basicRect)) : (r.sharpRect = t(r.sharpRect, i),
                r.basicRect = r.sharpRect),
            r)
    };
    function r(o) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1
            , a = arguments[2];
        return (o.ELEMENT_NODE == o.nodeType || o.TEXT_NODE == o.nodeType) && (o.TEXT_NODE == o.nodeType ? function(e, n) {
            if (!e.data)
                return !1;
            if (null == e.data.match(/\S/))
                return !1;
            if ("hidden" == (0,
                window.getComputedStyle)(e.parentElement).visibility)
                return !1;
            var r = e.parentElement.getBoundingClientRect()
                , o = t(n.basicRect, r)
                , i = o.left
                , a = o.top
                , c = o.right
                , d = o.bottom;
            return !(i >= c || a >= d)
        }(o, a) : !(!o.innerText && 1 == i) && (!e(o) && ("img" == o.nodeName.toLowerCase() && 2 == i ? function(e, n) {
            if (!e.src)
                return !1;
            if ("hidden" == (0,
                window.getComputedStyle)(e).visibility)
                return !1;
            var r = e.getBoundingClientRect()
                , o = t(n.basicRect, r)
                , i = o.left
                , a = o.top
                , c = o.right
                , d = o.bottom;
            return !(i >= c || a >= d)
        }(o, a) : function(e, t, o) {
            for (var i = n(e, o), a = e.childNodes, c = a.length, d = 0; d < c; d++) {
                var l = r(a[d], t, i);
                if (l)
                    return !0
            }
            return !1
        }(o, i, a))))
    }
    function o() {
        return !!window.Owl && (Owl.addError instanceof Function || (console.warn("没有引入cat"),
            !1))
    }
    var i = function() {
        var e = function() {
            Object.create(null);
            return {
                left: 0,
                top: 0,
                right: window.innerWidth,
                bottom: window.innerHeight
            }
        }()
            , n = document.getElementsByTagName("html")[0]
            , r = document.getElementsByTagName("body")[0]
            , o = window.getComputedStyle
            , i = Object.create(null);
        if (i.sharpRect = e,
            i.basicRect = i.sharpRect,
        "visible" != o(n).overflow && "visible" != o(r).overflow) {
            var a = r.getBoundingClientRect();
            i.basicRect = t(a, i.sharpRect)
        }
        return i
    }
        , a = {};
    function c(e, t) {
        a[e] = {
            value: t,
            ctime: (new Date).getTime()
        }
    }
    function d(r) {
        if ("html" == r.nodeName.toLocaleLowerCase() || "body" == r.nodeName.toLocaleLowerCase())
            return console.warn("请不要将data-rye设置在body或者html上"),
                !0;
        var o = function(e) {
            var t = []
                , n = e;
            for (; n; )
                t.unshift(n),
                    n = n.parentElement;
            return t
        }(r);
        o.pop();
        var a = o.shift()
            , c = o.shift();
        if (e(a) || e(c))
            return !1;
        for (var d = i(), l = 0; l < o.length; l++) {
            if (e(o[l]))
                return !1;
            d = n(o[l], d)
        }
        return !e(r) && function(e, n) {
            if ("hidden" == (0,
                window.getComputedStyle)(e).visibility)
                return !1;
            var r = e.getBoundingClientRect()
                , o = t(n.basicRect, r)
                , i = o.left
                , a = o.top
                , c = o.right
                , d = o.bottom;
            return !(i >= c || a >= d)
        }(r, d)
    }
    function l(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1
            , n = function(e) {
            return document.querySelectorAll('[key-dom="' + e + '"]')
        }(e);
        if (!n || !n.length)
            return !1;
        var r = 0;
        if (t == 1 / 0)
            for (var o = 0; o < n.length; o++) {
                if (!d(n[o]))
                    return !1
            }
        else
            for (var i = 0; i < n.length; i++) {
                if (d(n[i]) && ++r >= t)
                    return !0
            }
        return !1
    }
    function u(e) {
        var t = e.target || e.srcElement;
        if (t) {
            var n = t.nodeName;
            if (n) {
                if ("script" == (n = n.toLocaleLowerCase())) {
                    if (null === t.getAttribute("key-script"))
                        return;
                    !function(e) {
                        if (o()) {
                            var t = (e.target || e.srcElement).src;
                            Owl.addError({
                                name: "keyScriptError",
                                msg: t
                            })
                        }
                    }(e)
                }
                if ("link" == n) {
                    if (null === t.getAttribute("key-css"))
                        return;
                    !function(e) {
                        if (o()) {
                            var t = (e.target || e.srcElement).href;
                            Owl.addError({
                                name: "keyCssError",
                                msg: t
                            })
                        }
                    }(e)
                }
            }
        }
    }
    var s = function() {
        return window.globalParam && window.globalParam.t0 ? globalParam.t0 : this.__t0 ? this.__t0 : window.performance && window.performance.timing ? window.performance.timing.navigationStart : void 0
    }
        , f = function() {
        return this.tempFCPStampOfServer - s.call(this)
    }
        , p = function() {
        var e = this.tempFCPStampOfFrontEnd;
        if (document.querySelectorAll("[key-script]").length < 1)
            return e - s.call(this);
        var t = m.call(this)
            , n = 0;
        return this.__t0 && (n = this.__t0 - window.performance.timing.navigationStart),
            t > n ? t - n : 1
    }
        , m = function() {
        var e = [].slice.call(document.querySelectorAll("[key-script]"))
            , t = [].slice.call(document.querySelectorAll("[key-css]"))
            , n = window.performance.getEntriesByType("resource").filter(function(e) {
            return "img" !== e.initiatorType && "xmlhttprequest" !== e.initiatorType
        }).sort(function(e, t) {
            return t.responseEnd - e.responseEnd
        })
            , r = n.filter(function(n) {
            var r = e.find(function(e) {
                return e.src === n.name
            });
            return r = r || t.find(function(e) {
                return e.href === n.name
            })
        });
        return r.length < 1 ? n.length > 0 ? n[0].responseEnd : 0 : (r = r.sort(function(e, t) {
            return t.responseEnd - e.responseEnd
        }))[0].responseEnd
    };
    function v(e) {
        var t = e.cat1
            , n = void 0 === t ? "default" : t
            , r = e.cat2
            , i = void 0 === r ? "default" : r
            , a = e.cat3
            , c = void 0 === a ? "default" : a
            , d = e.level
            , l = void 0 === d ? "info" : d
            , u = e.info
            , s = void 0 === u ? "" : u
            , f = e.category
            , p = void 0 === f ? "wardenCustom" : f
            , m = e.sec_category
            , v = void 0 === m ? "default" : m
            , w = e.msg
            , g = !!o() && Owl.cfgManager._config
            , h = g && g.project || "warden";
        s instanceof Object && (s = JSON.stringify(s));
        var y = "tracer_type," + encodeURIComponent(n) + "|error_level_sub," + encodeURIComponent(i) + "|error_code," + encodeURIComponent(c) + "|level," + encodeURIComponent(l) + "|content," + encodeURIComponent(s)
            , b = [{
            msg: w,
            project: h,
            pageUrl: g && g.pageUrl || window.location.pathname,
            realUrl: window.location.href,
            category: p,
            timestamp: Date.now(),
            sec_category: v,
            level: l
        }];
        y && (b[0].content = y),
            function(e) {
                console.log(e.data,'23123132132123133')
                var t = e.data
                    , n = e.type
                    , r = e.url
                    , o = new XMLHttpRequest
                    , i = "c=" + encodeURIComponent(JSON.stringify(t));
                if ("GET" == n || "get" == n)
                    t ? o.open("GET", r + "?" + t, !0) : o.open("GET", r + "?t=" + Date.now(), !0),
                        o.send();
                else if (navigator && navigator.sendBeacon && "function" == typeof navigator.sendBeacon) {
                    var a = new FormData;
                    a.append("c", encodeURIComponent(JSON.stringify(t))),
                        navigator.sendBeacon(r, a)
                } else
                    o.open("POST", r, !1),
                        o.setRequestHeader("Content-type", "application/x-www-form-urlencoded"),
                        o.send(i)
            }({
                type: "post",
                url: "//catfront.dianping.com/api/log?v=1",
                data: b
            })
    }
    var w = function() {
        var e, t = function() {
            var e = (this.CONFIG || {}).renderType
                , t = void 0 === e ? "frontend" : e
                , n = 0;
            if (this.tempFCPStampByReport)
                return this.tempFCPStampByReport - s.call(this);
            switch (t) {
                case "server":
                    n = f.call(this);
                    break;
                case "frontend":
                default:
                    n = p.call(this)
            }
            return n
        }
            .call(this);
        e = t,
        o() && Owl.addPoint({
            position: 25,
            duration: e
        })
    };
    function g() {
        try {
            (function() {
                    Math.random() / 100 <= .001 && v({
                        cat1: "coverage",
                        cat2: "warden",
                        msg: "warden覆盖上报",
                        info: "warden覆盖上报",
                        category: "wardenReport",
                        sec_category: "wardenCoverage",
                        level: "info"
                    })
                }
            ).call(warden),
                w.call(warden)
        } catch (e) {
            console.log(e)
        }
    }
    var h = v;
    function y(e) {
        v({
            cat1: e.cat1,
            cat2: e.cat2,
            cat3: e.cat3,
            level: "warden",
            info: e.info
        })
    }
    function b(e, t, n, r, o) {
        void 0 !== e && void 0 !== t && void 0 !== n && void 0 === r ? (r = n,
            n = "default") : void 0 !== e && void 0 !== t && void 0 === n && void 0 === r ? (r = t,
            t = "default",
            n = "default") : void 0 !== e && void 0 === t && void 0 === n && void 0 === r && (r = e,
            e = "default",
            t = "default",
            n = "default"),
            v({
                cat1: e,
                cat2: t,
                cat3: n,
                level: o,
                info: r,
                sec_category: "wardenCustom"
            })
    }
    var E = window._MeiTuanWardenObject || "warden"
        , _ = window[E] || {};
    return _.isShow = function(e, t, n) {
        c("keyDom", !0);
        var r = l(e, t);
        return r || function(e, t, n) {
            o() && Owl.addError({
                name: "keyDomError",
                msg: e
            }, {
                tags: {
                    info: n
                }
            })
        }(e, 0, n),
            r
    }
        ,
        _.isWhite = function(t) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
            c("whiteScree", !0);
            var a = document.getElementsByTagName("html")[0]
                , d = document.getElementsByTagName("body")[0];
            if (e(a) || e(d))
                return !1;
            var l = r(d, n, i());
            return l || function(e) {
                o() && Owl.addError({
                    name: "whiteScreen",
                    msg: "页面白屏"
                }, {
                    tags: {
                        info: e
                    }
                })
            }(t),
                !l
        }
        ,
        _.reportKeyError = u,
        _.pageError = function(e, t) {
            o() && Owl.addError({
                name: "pageError",
                msg: e
            }, {
                tags: {
                    info: t,
                    refer: document.referrer
                }
            })
        }
        ,
        _.reportT5 = function(e) {
            var t, n, r, i = s.call(this), a = this.__t0s = this.__t0s || {};
            a[i] && console.warn("多次上报t5,请查看是否在同一页面多次调用warden.finish方法"),
                a[i] = !0,
                t = 13,
                n = e - i,
            o() && Owl.addPoint(t, n, r)
        }
        ,
        _.reportCustom = h,
        _.reportLx = function(e) {
            y({
                cat1: "lx",
                cat2: e.cat2,
                cat3: e.cat3,
                info: e.info
            })
        }
        ,
        _.reportApi = function(e, t, n) {
            y({
                cat1: "api",
                cat2: e,
                cat3: t,
                info: n
            })
        }
        ,
        _.reportWarn = function(e, t, n, r) {
            b(e, t, n, r, "warn")
        }
        ,
        _.reportInfo = function(e, t, n, r) {
            b(e, t, n, r, "info")
        }
        ,
        _.reportError = function(e, t, n, r) {
            b(e, t, n, r, "error")
        }
        ,
        _.report = v,
        function() {
            if (window.history) {
                var e = history.pushState.bind(history)
                    , t = history.replaceState.bind(history)
                    , n = this;
                history.pushState = function() {
                    n.__t0 = (new Date).getTime(),
                        e.apply(void 0, arguments)
                }
                    ,
                    history.replaceState = function() {
                        n.__t0 = (new Date).getTime(),
                            t.apply(void 0, arguments)
                    }
                    ,
                    window.addEventListener("popstate", function() {
                        n.__t0 = (new Date).getTime()
                    })
            }
        }
            .call(_),
        function() {
            var e = this;
            window.addEventListener("hashchange", function(t) {
                e.__t0 = (new Date).getTime()
            })
        }
            .call(_),
        _.__ready = !0,
        _.__inits = _.__inits || [],
        _.__errs = _.__errs || [],
        _.__inits.forEach(function(e) {
            e instanceof Function && e(_);
            var t = document.querySelectorAll("[key-css]").length
                , n = document.querySelectorAll("[key-script]").length;
            t > 0 && c("keyCss", !0),
            n > 0 && c("keyScript", !0)
        }),
        _.__errs.forEach(function(e) {
            u(e)
        }),
        window.attachEvent ? window.attachEvent("beforeunload", g) : window.addEventListener && window.addEventListener("beforeunload", g, !1),
        _
});
