/*!
 * thunder-service-worker-runtime v2.2.0
 * (c) 2019-01-08 20:37:41 */
!function () {
    "use strict";

    function e(e, t) {
        if (void 0 === e || null === e) throw new TypeError("Cannot convert first argument to object");
        for (var n = Object(e), r = 1; r < arguments.length; r++) {
            var o = arguments[r];
            if (void 0 !== o && null !== o) for (var i = Object.keys(Object(o)), a = 0, s = i.length; a < s; a++) {
                var c = i[a], u = Object.getOwnPropertyDescriptor(o, c);
                void 0 !== u && u.enumerable && (n[c] = o[c])
            }
        }
        return n
    }

    function t(e) {
        return e instanceof RegExp ? e : e instanceof Array ? e.map(t) : new RegExp(e)
    }

    function n() {
        return performance && "now" in performance ? performance.now() : Date.now()
    }

    function r(e) {
        return caches.open(e)
    }

    function o() {
        if (self.serviceWorkerRuntime && self.serviceWorkerRuntime.options.debug) {
            for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            var r = t[0], o = void 0;
            console[r] ? (o = console[r], t.shift()) : o = console.log, t.unshift("[Thunder-SW]"), o.apply(console, t)
        }
    }

    function i(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
        return r(e).then(function (e) {
            if (e.addAll) return e.addAll(t)
        }).then(function () {
            o("[preCache] cache added", t)
        }).catch(function (e) {
            o(e)
        })
    }

    function a(e, t) {
        var n = "$$$thunder-serviceworker$$$" + t.scope;
        return caches.keys().then(function (t) {
            t.map(function (t) {
                -1 !== t.indexOf(n) && (e !== t ? (o("delete ", t), caches.delete(t)) : o("current cache is ", e))
            })
        })
    }

    function s(e, t) {
        var n = {}, r = !0, o = !1, i = void 0;
        try {
            for (var a, s = e.entries()[Symbol.iterator](); !(r = (a = s.next()).done); r = !0) {
                var c = a.value;
                n[c[0]] = c[1]
            }
        } catch (e) {
            o = !0, i = e
        } finally {
            try {
                !r && s.return && s.return()
            } finally {
                if (o) throw i
            }
        }
        return n["X-Thunder-User-Agent"] = t.userAgent, n
    }

    function c(e, t) {
        var n = new RegExp("^" + location.origin.replace(/\./g, "\\.").replace(/\//g, "\\/")), r = void 0;
        if (n.test(e.url)) {
            var o = {method: e.method, mode: "cors", credentials: "same-origin", headers: s(e.headers, t)};
            r = "GET" !== e.method && "HEAD" !== e.method ? e.blob().then(function (t) {
                return o.body = t, fetch(e.url, o)
            }) : fetch(e.url, o)
        } else r = fetch(e);
        return r
    }

    function u(e, t) {
        this.message = e, this.statusCode = t
    }

    var h = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
            return typeof e
        } : function (e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        }, l = function (e) {
            return function () {
                var t = e.apply(this, arguments);
                return new Promise(function (e, n) {
                    function r(o, i) {
                        try {
                            var a = t[o](i), s = a.value
                        } catch (e) {
                            return void n(e)
                        }
                        if (!a.done) return Promise.resolve(s).then(function (e) {
                            r("next", e)
                        }, function (e) {
                            r("throw", e)
                        });
                        e(s)
                    }

                    return r("next")
                })
            }
        }, f = function (e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }, p = function () {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }

            return function (t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(), d = function (e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }, v = function (e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }, g = (function (e, t) {
            t = {exports: {}}, e(t, t.exports), t.exports
        }(function (e) {
            !function (t) {
                function n(e, t, n, r) {
                    var i = t && t.prototype instanceof o ? t : o, a = Object.create(i.prototype), s = new d(r || []);
                    return a._invoke = u(e, n, s), a
                }

                function r(e, t, n) {
                    try {
                        return {type: "normal", arg: e.call(t, n)}
                    } catch (e) {
                        return {type: "throw", arg: e}
                    }
                }

                function o() {
                }

                function i() {
                }

                function a() {
                }

                function s(e) {
                    ["next", "throw", "return"].forEach(function (t) {
                        e[t] = function (e) {
                            return this._invoke(t, e)
                        }
                    })
                }

                function c(e) {
                    function t(n, o, i, a) {
                        var s = r(e[n], e, o);
                        if ("throw" !== s.type) {
                            var c = s.arg, u = c.value;
                            return u && "object" === (void 0 === u ? "undefined" : h(u)) && k.call(u, "__await") ? Promise.resolve(u.__await).then(function (e) {
                                t("next", e, i, a)
                            }, function (e) {
                                t("throw", e, i, a)
                            }) : Promise.resolve(u).then(function (e) {
                                c.value = e, i(c)
                            }, a)
                        }
                        a(s.arg)
                    }

                    function n(e, n) {
                        function r() {
                            return new Promise(function (r, o) {
                                t(e, n, r, o)
                            })
                        }

                        return o = o ? o.then(r, r) : r()
                    }

                    var o;
                    this._invoke = n
                }

                function u(e, t, n) {
                    var o = E;
                    return function (i, a) {
                        if (o === A) throw new Error("Generator is already running");
                        if (o === R) {
                            if ("throw" === i) throw a;
                            return g()
                        }
                        for (n.method = i, n.arg = a; ;) {
                            var s = n.delegate;
                            if (s) {
                                var c = l(s, n);
                                if (c) {
                                    if (c === O) continue;
                                    return c
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg; else if ("throw" === n.method) {
                                if (o === E) throw o = R, n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            o = A;
                            var u = r(e, t, n);
                            if ("normal" === u.type) {
                                if (o = n.done ? R : C, u.arg === O) continue;
                                return {value: u.arg, done: n.done}
                            }
                            "throw" === u.type && (o = R, n.method = "throw", n.arg = u.arg)
                        }
                    }
                }

                function l(e, t) {
                    var n = e.iterator[t.method];
                    if (n === y) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = y, l(e, t), "throw" === t.method)) return O;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return O
                    }
                    var o = r(n, e.iterator, t.arg);
                    if ("throw" === o.type) return t.method = "throw", t.arg = o.arg, t.delegate = null, O;
                    var i = o.arg;
                    return i ? i.done ? (t[e.resultName] = i.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = y), t.delegate = null, O) : i : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, O)
                }

                function f(e) {
                    var t = {tryLoc: e[0]};
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function p(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function d(e) {
                    this.tryEntries = [{tryLoc: "root"}], e.forEach(f, this), this.reset(!0)
                }

                function v(e) {
                    if (e) {
                        var t = e[b];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var n = -1, r = function t() {
                                for (; ++n < e.length;) if (k.call(e, n)) return t.value = e[n], t.done = !1, t;
                                return t.value = y, t.done = !0, t
                            };
                            return r.next = r
                        }
                    }
                    return {next: g}
                }

                function g() {
                    return {value: y, done: !0}
                }

                var y, m = Object.prototype, k = m.hasOwnProperty, w = "function" == typeof Symbol ? Symbol : {},
                    b = w.iterator || "@@iterator", _ = w.asyncIterator || "@@asyncIterator",
                    x = w.toStringTag || "@@toStringTag", S = t.regeneratorRuntime;
                if (S) return void(e.exports = S);
                S = t.regeneratorRuntime = e.exports, S.wrap = n;
                var E = "suspendedStart", C = "suspendedYield", A = "executing", R = "completed", O = {}, P = {};
                P[b] = function () {
                    return this
                };
                var L = Object.getPrototypeOf, N = L && L(L(v([])));
                N && N !== m && k.call(N, b) && (P = N);
                var $ = a.prototype = o.prototype = Object.create(P);
                i.prototype = $.constructor = a, a.constructor = i, a[x] = i.displayName = "GeneratorFunction", S.isGeneratorFunction = function (e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === i || "GeneratorFunction" === (t.displayName || t.name))
                }, S.mark = function (e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, a) : (e.__proto__ = a, x in e || (e[x] = "GeneratorFunction")), e.prototype = Object.create($), e
                }, S.awrap = function (e) {
                    return {__await: e}
                }, s(c.prototype), c.prototype[_] = function () {
                    return this
                }, S.AsyncIterator = c, S.async = function (e, t, r, o) {
                    var i = new c(n(e, t, r, o));
                    return S.isGeneratorFunction(t) ? i : i.next().then(function (e) {
                        return e.done ? e.value : i.next()
                    })
                }, s($), $[x] = "Generator", $[b] = function () {
                    return this
                }, $.toString = function () {
                    return "[object Generator]"
                }, S.keys = function (e) {
                    var t = [];
                    for (var n in e) t.push(n);
                    return t.reverse(), function n() {
                        for (; t.length;) {
                            var r = t.pop();
                            if (r in e) return n.value = r, n.done = !1, n
                        }
                        return n.done = !0, n
                    }
                }, S.values = v, d.prototype = {
                    constructor: d, reset: function (e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = y, this.done = !1, this.delegate = null, this.method = "next", this.arg = y, this.tryEntries.forEach(p), !e) for (var t in this) "t" === t.charAt(0) && k.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = y)
                    }, stop: function () {
                        this.done = !0;
                        var e = this.tryEntries[0], t = e.completion;
                        if ("throw" === t.type) throw t.arg;
                        return this.rval
                    }, dispatchException: function (e) {
                        function t(t, r) {
                            return i.type = "throw", i.arg = e, n.next = t, r && (n.method = "next", n.arg = y), !!r
                        }

                        if (this.done) throw e;
                        for (var n = this, r = this.tryEntries.length - 1; r >= 0; --r) {
                            var o = this.tryEntries[r], i = o.completion;
                            if ("root" === o.tryLoc) return t("end");
                            if (o.tryLoc <= this.prev) {
                                var a = k.call(o, "catchLoc"), s = k.call(o, "finallyLoc");
                                if (a && s) {
                                    if (this.prev < o.catchLoc) return t(o.catchLoc, !0);
                                    if (this.prev < o.finallyLoc) return t(o.finallyLoc)
                                } else if (a) {
                                    if (this.prev < o.catchLoc) return t(o.catchLoc, !0)
                                } else {
                                    if (!s) throw new Error("try statement without catch or finally");
                                    if (this.prev < o.finallyLoc) return t(o.finallyLoc)
                                }
                            }
                        }
                    }, abrupt: function (e, t) {
                        for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                            var r = this.tryEntries[n];
                            if (r.tryLoc <= this.prev && k.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                                var o = r;
                                break
                            }
                        }
                        o && ("break" === e || "continue" === e) && o.tryLoc <= t && t <= o.finallyLoc && (o = null);
                        var i = o ? o.completion : {};
                        return i.type = e, i.arg = t, o ? (this.method = "next", this.next = o.finallyLoc, O) : this.complete(i)
                    }, complete: function (e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), O
                    }, finish: function (e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), p(n), O
                        }
                    }, catch: function (e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var o = r.arg;
                                    p(n)
                                }
                                return o
                            }
                        }
                        throw new Error("illegal catch attempt")
                    }, delegateYield: function (e, t, n) {
                        return this.delegate = {
                            iterator: v(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = y), O
                    }
                }
            }(function () {
                return this
            }() || Function("return this")())
        }), Boolean("localhost" === location.hostname || "[::1]" === location.hostname || location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/))),
        y = function () {
            function t() {
                f(this, t), this.logQueue = [], this.markQueue = {}
            }

            return p(t, [{
                key: "mark", value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    e && (this.markQueue[e] = {createdAt: n(), data: t})
                }
            }, {
                key: "markEnd", value: function (t, r) {
                    var o = this.markQueue[t];
                    if (o) {
                        var i = n(), a = i - o.createdAt, s = {key: t, data: e(o.data, {cost: a}, r)};
                        this.logQueue.push(s), delete this.markQueue[t]
                    }
                }
            }, {
                key: "markOnce", value: function (e, t) {
                    this.mark(e, t), this.markEnd(e, t)
                }
            }]), t
        }(), m = function () {
            function e(t) {
                f(this, e), this.name = t, this.db = null, this.ready = this.init()
            }

            return p(e, [{
                key: "init", value: function () {
                    var e = this;
                    return new Promise(function (t, n) {
                        var r = indexedDB.open(e.name);
                        r.onupgradeneeded = function (t) {
                            e.db = t.target.result, e.db.createObjectStore("store")
                        }, r.onsuccess = function (n) {
                            e.db = n.target.result, t()
                        }, r.onerror = function (t) {
                            e.db = t.target.result, n(t)
                        }
                    })
                }
            }, {
                key: "get", value: function () {
                    function e(e) {
                        return t.apply(this, arguments)
                    }

                    var t = l(regeneratorRuntime.mark(function e(t) {
                        var n = this;
                        return regeneratorRuntime.wrap(function (e) {
                            for (; ;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.ready;
                                case 2:
                                    return e.abrupt("return", new Promise(function (e, r) {
                                        var o = n.getStore("readonly").get(t);
                                        o.onsuccess = function (t) {
                                            return e(t.target.result)
                                        }, o.onerror = r
                                    }));
                                case 3:
                                case"end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return e
                }()
            }, {
                key: "getStore", value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "readwrite";
                    try {
                        return this.db.transaction(["store"], e).objectStore("store")
                    } catch (e) {
                        o("[ IndexedDBStorage getStore ]", e), this.ready = this.init()
                    }
                }
            }, {
                key: "set", value: function () {
                    function e(e, n) {
                        return t.apply(this, arguments)
                    }

                    var t = l(regeneratorRuntime.mark(function e(t, n) {
                        var r = this;
                        return regeneratorRuntime.wrap(function (e) {
                            for (; ;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.ready;
                                case 2:
                                    return e.abrupt("return", new Promise(function (e, o) {
                                        var i = r.getStore().put(n, t);
                                        i.onsuccess = e, i.onerror = o
                                    }));
                                case 3:
                                case"end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return e
                }()
            }, {
                key: "count", value: function () {
                    function e() {
                        return t.apply(this, arguments)
                    }

                    var t = l(regeneratorRuntime.mark(function e() {
                        var t = this;
                        return regeneratorRuntime.wrap(function (e) {
                            for (; ;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.ready;
                                case 2:
                                    return e.abrupt("return", new Promise(function (e, n) {
                                        var r = t.getStore().count();
                                        r.onsuccess = function (t) {
                                            return e(t.target.result)
                                        }, r.onerror = n
                                    }));
                                case 3:
                                case"end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return e
                }()
            }, {
                key: "keys", value: function () {
                    function e() {
                        return t.apply(this, arguments)
                    }

                    var t = l(regeneratorRuntime.mark(function e() {
                        var t = this;
                        return regeneratorRuntime.wrap(function (e) {
                            for (; ;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.ready;
                                case 2:
                                    return e.abrupt("return", new Promise(function (e, n) {
                                        var r = void 0, o = t.getStore();
                                        if ("getAllKeys" in o.constructor.prototype) r = o.getAllKeys(), r.onsuccess = function (t) {
                                            return e(t.target.result)
                                        }; else {
                                            r = o.openCursor();
                                            var i = [];
                                            r.onsuccess = function (t) {
                                                var n = t.target.result;
                                                n ? (i.push(n.key), n.continue()) : e(i)
                                            }
                                        }
                                        r.onerror = n
                                    }));
                                case 3:
                                case"end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return e
                }()
            }, {
                key: "delete", value: function () {
                    function e(e) {
                        return t.apply(this, arguments)
                    }

                    var t = l(regeneratorRuntime.mark(function e(t) {
                        var n = this;
                        return regeneratorRuntime.wrap(function (e) {
                            for (; ;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.ready;
                                case 2:
                                    return e.abrupt("return", new Promise(function (e, r) {
                                        var o = n.getStore().delete(t);
                                        o.onsuccess = function (t) {
                                            return e(t.target.result)
                                        }, o.onerror = r
                                    }));
                                case 3:
                                case"end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return e
                }()
            }, {
                key: "clear", value: function (e, t) {
                    indexedDB.deleteDatabase(this.name)
                }
            }]), e
        }(), k = function () {
            function e() {
                f(this, e), this._listeners = {}
            }

            return p(e, [{
                key: "$on", value: function (e, t, n) {
                    return n = n || null, this._listeners[e] || (this._listeners[e] = []), this._listeners[e].push({
                        cb: t,
                        ctx: n
                    }), this._listeners[e].length - 1
                }
            }, {
                key: "$once", value: function (e, t, n) {
                    n = n || null
                }
            }, {
                key: "$off", value: function (e, t) {
                    var n = this;
                    this._listeners[e] && this._listeners[e].length && (t || (this._listeners[e].map(function (e) {
                        return null
                    }), this._listeners[e] = []), "function" == typeof t && this._listeners[e].map(function (r, o) {
                        r.cb === t && (n._listeners[e].splice(o, 1), r = null)
                    }), "number" == typeof t && this._listeners[e].splice(t, 1))
                }
            }, {
                key: "$emit", value: function () {
                    for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    if (t.length) {
                        var r = t[0];
                        t.shift(), this._listeners[r] && this._listeners[r].length && this._listeners[r].map(function (e) {
                            e.cb.apply(e.ctx, t)
                        })
                    }
                }
            }]), e
        }(), w = function () {
            function e(n) {
                var r = n.name, o = n.cacheName, i = n.cacheStore, a = n.helpers, s = n.options;
                f(this, e), this.name = r, this.cacheName = o, this.helpers = a, this.cacheStore = i, this.state = s;
                var c = s.strategies[this.name] || {};
                c instanceof Array ? this.options = {
                    includes: t(c),
                    excludes: []
                } : this.options = {includes: t(c.includes || []), excludes: t(c.excludes || [])}
            }

            return p(e, [{
                key: "getCache", value: function () {
                    return caches.open(this.cacheName).then(function (e) {
                        return e
                    })
                }
            }, {
                key: "test", value: function (e) {
                    if (!e || !e.url) return !1;
                    var t = !1, n = !1, r = e.url;
                    return this.options ? (this.options.excludes.map(function (e) {
                        n || (n = e.test(r))
                    }), n ? t : (this.options.includes.map(function (e) {
                        t || (t = e.test(r))
                    }), t)) : t
                }
            }, {
                key: "debug", value: function (e) {
                    o("[Strategies " + this.name + "]: " + e)
                }
            }]), e
        }(), b = function (e) {
            function t(e) {
                var n = e.cacheName, r = e.cacheStore, o = e.helpers, i = e.options;
                return f(this, t), v(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, {
                    name: "CacheFirst",
                    cacheName: n,
                    cacheStore: r,
                    helpers: o,
                    options: i
                }))
            }

            return d(t, e), p(t, [{
                key: "handleRequest", value: function (e) {
                    return this.cacheFirst(e)
                }
            }, {
                key: "cacheFirst", value: function (e) {
                    var t = this, n = void 0;
                    return this.getCache().then(function (t) {
                        return t.match(e)
                    }).then(function (r) {
                        return !!r && (n = r, t.helpers.isCacheFresh(e))
                    }).then(function (r) {
                        return r ? (t.helpers.logger.markEnd(e.url, {strategy: "cacheFirst"}), t.debug("✅ cache " + e.url), n) : (t.debug("❌ network " + e.url), t.helpers.fetchAndCache(e))
                    })
                }
            }]), t
        }(w), _ = function (e) {
            function t(e) {
                var n = e.cacheName, r = e.cacheStore, o = e.helpers, i = e.options;
                return f(this, t), v(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, {
                    name: "CacheAndRefresh",
                    cacheName: n,
                    cacheStore: r,
                    helpers: o,
                    options: i
                }))
            }

            return d(t, e), p(t, [{
                key: "handleRequest", value: function (e) {
                    return this.cacheAndRefresh(e)
                }
            }, {
                key: "notifyUpdate", value: function (e, t) {
                    if (e && e.url) return e.headers.get("ETag") === t.headers.get("ETag") ? this.debug("[notifyUpdate]: ignore") : void 0
                }
            }, {
                key: "cacheAndRefresh", value: function (e) {
                    var t = this;
                    return this.getCache().then(function (t) {
                        return t.match(e)
                    }).then(function (n) {
                        return n ? (t.helpers.logger.markEnd(e.url, {strategy: "cacheAndRefresh"}), t.debug("✅ cacheAndRefresh ", e.url), t.helpers.fetchAndCache(e).then(function (e) {
                            t.notifyUpdate(e, n)
                        }), n) : t.helpers.fetchAndCache(e)
                    })
                }
            }]), t
        }(w), x = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/,
        S = /[?&]([^=&#]+)=([^&#]*)/g, E = {CLIENT_PATCH_ERROR: 416, UNKNOWN_ERROR: 400, LOCAL_VERSION_NOT_FOUND: 205},
        C = function (e) {
            function t(e) {
                var n = e.cacheName, r = e.cacheStore, o = e.helpers, i = e.options, a = e.state;
                f(this, t);
                var s = v(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, {
                    name: "StarkDiff",
                    cacheName: n,
                    cacheStore: r,
                    helpers: o,
                    options: i
                }));
                return s.state = a, s
            }

            return d(t, e), p(t, [{
                key: "handleRequest", value: function (e) {
                    return this.StarkDiff(e)
                }
            }, {
                key: "StarkDiff", value: function (e) {
                    var t = this;
                    return this.getCache().then(function (t) {
                        return t.match(e)
                    }).then(function (n) {
                        return n || t.noCache(e)
                    })
                }
            }, {
                key: "noCache", value: function (e) {
                    var t = this, n = this.parseUrl(e.url);
                    if (!n) return this.starkFetch(e);
                    var r = n.chunkName, o = "$$$diff_chunk#" + r;
                    return this.cacheStore.get(o).then(function (r) {
                        return r ? t.patchChunk(e, n, r) : (t.updateChunkInfo(n), t.starkFetch(e))
                    })
                }
            }, {
                key: "parseUrl", value: function (e) {
                    var t = decodeURIComponent(e), n = t.match(S),
                        r = {chunkName: "", hash: "", chunkType: "", cacheUrl: ""};
                    if (n && n.length) {
                        var o = {};
                        n.forEach(function (e) {
                            var t = e.split("=");
                            o[t[0].slice(1)] = t[1] || ""
                        });
                        var i = o.chunkName, a = o.hash, s = o.chunkType;
                        r.chunkName = i, r.hash = a, r.chunkType = s, r.cacheUrl = t
                    }
                    return r.chunkName && r.hash ? r : null
                }
            }, {
                key: "starkFetch", value: function (e) {
                    var t = this;
                    return fetch(e.url).then(function (n) {
                        return t.helpers.add(e, n.clone()), n
                    })
                }
            }, {
                key: "updateChunkInfo", value: function (e) {
                    var t = e.chunkName;
                    return this.cacheStore.set("$$$diff_chunk#" + t, e)
                }
            }, {
                key: "patchChunk", value: function (e, t, n) {
                    var r = this;
                    if (t.hash === n.hash) return this.starkFetch(e);
                    var o = this.getPatchLink(t, n), i = n.cacheUrl;
                    return Promise.all([fetch(o).then(function (e) {
                        return e.json()
                    }), this.getCache().then(function (e) {
                        return e.match(i)
                    }).then(function (e) {
                        return e ? e.text() : null
                    })]).then(function (e) {
                        var t = e[0], n = e[1];
                        return n && t ? r.recoverMin(n, t.content) : {content: !1}
                    }).then(function (n) {
                        if (!n.content) return r.starkFetch(e);
                        var o = n.content, i = new Blob([o], {type: "application/javascript"}), a = new Response(i);
                        return r.helpers.add(e, a.clone()), r.updateChunkInfo(t), a
                    })
                }
            }, {
                key: "getPatchLink", value: function (e, t) {
                    var n = this.state.StarkOptions.projectName, r = this.getPatchPath(e.cacheUrl),
                        o = this.getPatchPath(t.cacheUrl);
                    return ["https://jarvas-static.meituan.net/diff/", n, "?", "oldFilePath=", encodeURIComponent(o), "&", "newFilePath=", encodeURIComponent(r)].join("")
                }
            }, {
                key: "getPatchPath", value: function (e) {
                    var t = this.state.outputOptions.publicPath, n = new RegExp(".*" + t);
                    return e.replace(n, "").replace(/\?.*/, "")
                }
            }, {
                key: "recoverMin", value: function () {
                    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", n = t.split("\t"), r = e, o = 0, i = 0; i < n.length; i++) {
                        var a = n[i][0];
                        if ("=" === a) o += parseInt(n[i].slice(1), 10); else if ("-" === a) {
                            var s = parseInt(n[i].slice(1), 10);
                            r = r.slice(0, o) + r.slice(o + s)
                        } else {
                            if ("+" !== a) throw new u("Broken patch found", E.CLIENT_PATCH_ERROR);
                            var c = decodeURI(n[i].slice(1));
                            r = r.slice(0, o) + c + r.slice(o), o += c.length
                        }
                    }
                    return {content: r, fullLength: r.length, patchLength: t.length}
                }
            }, {
                key: "test", value: function (e) {
                    if (!e || !e.url) return !1;
                    var t = e.url;
                    if (t.indexOf("s3plus.meituan.net/v1/mss_e2821d7f0cfe4ac1bf9202ecf9590e67/cdn-prod") < 0) return !1;
                    var n = x.exec(t), r = n ? n[5] : "", o = r.split(".");
                    return "js" === o[o.length - 1]
                }
            }]), t
        }(w), A = /^https/, R = /^0|([123]\d\d)|(40[14567])|410$/, O = function (e) {
            function t(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = arguments[2];
                f(this, t);
                var o = v(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                return o.runtime = e, o.options = n, o.cacheName = o.options.cache.name, o.state = r, o.cacheStore = new m("$$$thunder-serviceworker$$$" + o.options.scope), o._timer = null, o.strategies = o.initStrategies(), o
            }

            return d(t, e), p(t, [{
                key: "initStrategies", value: function () {
                    var e = {
                        cacheName: this.cacheName,
                        cacheStore: this.cacheStore,
                        helpers: {
                            logger: this.runtime.logger,
                            fetchAndCache: this.fetchAndCache.bind(this),
                            isCacheFresh: this.isCacheFresh.bind(this),
                            add: this.add.bind(this)
                        },
                        options: this.options,
                        state: this.state
                    };
                    return [C, _, b].map(function (t) {
                        return new t(e)
                    })
                }
            }, {
                key: "getCache", value: function () {
                    return caches.open(this.cacheName).then(function (e) {
                        return e
                    })
                }
            }, {
                key: "isCacheFresh", value: function (e) {
                    var t = this;
                    return this.cacheStore.get(e.url).then(function (n) {
                        if (!n) return !1;
                        var r = Date.now(), o = r - n.createdAt < 1e3 * t.options.cacheMaxAgeSeconds;
                        return o && t.cacheStore.set(e.url, {createdAt: n.createdAt, usedAt: r, use: n.use + 1}), o
                    })
                }
            }, {
                key: "shouldCache", value: function (e, t) {
                    var n = this.options.successResponses || R;
                    return "GET" === e.method && (!!n.test(t.status) && this.useCache(e))
                }
            }, {
                key: "useCache", value: function (e) {
                    var t = !1, n = e.url;
                    if (!g && !A.test(n)) return !1;
                    for (var r = 0, o = this.strategies.length; r < o; r++) if (this.strategies[r].test(e)) {
                        t = !0;
                        break
                    }
                    return t
                }
            }, {
                key: "add", value: function (e, t) {
                    var n = this;
                    return this.shouldCache(e, t) ? this.getCache().then(function (n) {
                        return n.put(e, t.clone())
                    }).then(function () {
                        var t = Date.now();
                        return n.cacheStore.set(e.url, {createdAt: t, usedAt: t, use: 1})
                    }) : (o("[CacheManager add]: should not Cache", e.method, e.url), Promise.resolve())
                }
            }, {
                key: "keys", value: function () {
                    return this.getCache().then(function (e) {
                        return e.keys()
                    }).then(function (e) {
                        return e.map(function (e) {
                            return e.url
                        }).sort()
                    })
                }
            }, {
                key: "get", value: function (e) {
                    var t = this;
                    this._clearJob();
                    for (var n = void 0, r = 0, i = this.strategies.length; r < i; r++) if (this.strategies[r].test(e)) {
                        n = this.strategies[r];
                        break
                    }
                    return n ? n.handleRequest(e).then(function (e) {
                        return e
                    }, function (r) {
                        return o("[❌ " + n.name + " error at: ]", r), t.fetchAndCache(e)
                    }) : (o("[cacheManager] no strategy to handle this request", e.url), fetch(e))
                }
            }, {
                key: "fetchAndCache", value: function (e) {
                    var t = this;
                    return c(e, this.options).then(function (n) {
                        return t.shouldCache(e, n) ? (t.add(e, n), n.clone()) : n.clone()
                    })
                }
            }, {
                key: "_clearJob", value: function () {
                    var e = this;
                    this._timer && clearTimeout(this._timer), this._timer = setTimeout(function () {
                        e.clearExpiredCaches().then(function () {
                            return e.clearOverSizeCaches()
                        }), e._timer = null
                    }, 800)
                }
            }, {
                key: "clear", value: function () {
                    return this._cache = null, caches.delete(this.cacheName)
                }
            }, {
                key: "clearOverSizeCaches", value: function () {
                    var e = this;
                    return this.cacheStore.count().then(function (t) {
                        var n = e.options.cache.maxEntries || 200, r = t - n;
                        if (!(r < 1)) return e.clearOldCaches(r)
                    })
                }
            }, {
                key: "clearOldCaches", value: function () {
                    var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
                    return this.cacheStore.keys().then(function (n) {
                        for (var r = n.filter(function (e) {
                            return e.val && e.val.createdAt
                        }).sort(function (e, t) {
                            return e.val.usedAt - t.val.usedAt
                        }), o = [], i = 0; i < t; i++) {
                            var a = r.shift();
                            if (!a) break;
                            o.push(e.delete(a.key))
                        }
                        return Promise.all(o)
                    })
                }
            }, {
                key: "clearExpiredCaches", value: function () {
                    var e = this;
                    return this.cacheStore.keys().then(function (t) {
                        var n = t.filter(function (e) {
                            return e.val && e.val.createdAt
                        }), r = [], o = Date.now();
                        return n.map(function (t) {
                            var n = t.val;
                            o - n.createdAt > 1e3 * e.options.cacheMaxAgeSeconds && r.push(e.delete(t.key))
                        }), Promise.all(r)
                    })
                }
            }, {
                key: "delete", value: function (e) {
                    var t = this;
                    return this.getCache().then(function (t) {
                        return t.delete(e)
                    }).then(function () {
                        return t.cacheStore.delete(e)
                    })
                }
            }]), t
        }(k);
    self.registration ? self.registration.scope : self.scope || new URL("./", self.location).href;
    var P = {
        successResponses: /^0|([123]\d\d)|(40[14567])|410$/,
        preCacheItems: [],
        networkTimeoutSeconds: null,
        debug: !0,
        strategies: {},
        cacheMaxAgeSeconds: 1209600,
        maxEntries: 200,
        cache: {name: "$$$thunder-serviceworker$$$/$$$", maxEntries: 200, queryOptions: null},
        userAgent: ""
    };
    self.addEventListener("sync", function (e) {
        "outbox" === e.tag && e.waitUntil(self.serviceWorkerRuntime.syncJob(e))
    });
    var L = function () {
        function n(t) {
            f(this, n), this.options = e({}, P), this.cacheManager = null, this.messageHandler = this._messageHandler.bind(this), this.fetchHandler = this._fetchHandler.bind(this), this.logger = new y, this._initJob = null
        }

        return p(n, [{
            key: "init", value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.serviceWorker;
                return this.state = e, n.successResponses && (n.successResponses = t(n.successResponses)), this.options = Object.assign(this.options, n), this.options.debug = !!n.debug, this.options.cache.maxEntries = n.maxEntries, this.cacheManager = new O(this, this.options, this.state), this.cacheManager.$on("msg", this.postMessage, this), this.fetchHandler = this._fetchHandler.bind(this), this._initJob = this.updateCache(), this._initJob
            }
        }, {
            key: "syncJob", value: function (e) {
                var t = this;
                return new Promise(function (n, r) {
                    setTimeout(function () {
                        o("⚠️ sync_event", e), n(), t.postMessage({type: "thudner:sync", data: null})
                    }, 2e3)
                })
            }
        }, {
            key: "postMessage", value: function (e) {
                clients.matchAll({includeUncontrolled: !0}).then(function (t) {
                    t.forEach(function (t) {
                        return t.postMessage(e)
                    })
                })
            }
        }, {
            key: "updateCache", value: function () {
                var e = this, t = this.options.cache.name;
                return a(t, this.options).then(function () {
                    return i(t, e.options.preCacheItems)
                })
            }
        }, {
            key: "_fetchHandler", value: function (e) {
                var t = this;
                if (this.cacheManager) {
                    var n = e.request.url, r = this.cacheManager.useCache(e.request), o = Promise.resolve();
                    r && (this.options.userAgent ? (this.logger.mark(n), o = this.cacheManager.get(e.request), e.respondWith(o), "waitUntil" in e && e.waitUntil(o)) : this.cacheManager.cacheStore.get("options:userAgent").then(function (e) {
                        t.options.userAgent = e || ""
                    }))
                }
            }
        }, {
            key: "_messageHandler", value: function (e) {
                var t = this, n = Promise.resolve();
                n.then(function () {
                    switch (e.data.command) {
                        case"update:ua":
                            return t.options.userAgent = e.data.userAgent, void t.cacheManager.cacheStore.set("options:userAgent", e.data.userAgent).then(function () {
                                e.ports[0].postMessage({error: null, data: t.options})
                            });
                        case"cache:keys":
                            return t.cacheManager.keys().then(function (t) {
                                e.ports[0].postMessage({error: null, data: t})
                            });
                        case"cache:add":
                            var n = new Request(e.data.url, {mode: "no-cors"});
                            return t.cacheManager.fetchAndCache(n).then(function () {
                                e.ports[0].postMessage({error: null})
                            });
                        case"cache:delete":
                            return t.cacheManager.delete(e.data.url).then(function (t) {
                                e.ports[0].postMessage({error: t ? null : "Item was not found in the cache."})
                            });
                        case"cache:clear":
                            return t.cacheManager.clear().then(function () {
                                e.ports[0].postMessage({error: null, data: "cache cleared"})
                            });
                        case"log":
                            return e.ports[0].postMessage({data: t.logger.logQueue}), void(t.logger.logQueue = []);
                        case"store:get":
                            return t.cacheManager.cacheStore.get(e.data.key).then(function (t) {
                                return e.ports[0].postMessage({val: t})
                            });
                        case"store:set":
                            return t.cacheManager.cacheStore.set(e.data.key, e.data.val).then(function () {
                                return e.ports[0].postMessage({err: null})
                            });
                        default:
                            throw Error("Unknown command: " + e.data.command)
                    }
                }).catch(function (t) {
                    o("error", "Message handling failed:", t), e.ports[0].postMessage({error: t.toString()})
                }), "waitUntil" in e && e.waitUntil(n)
            }
        }]), n
    }(), N = {};
    try {
        N = JSON.parse(atob("eyJ2ZXJzaW9uIjoyLCJyZXNvdXJjZXMiOlt7Im5hbWUiOiJkaWZmZXIiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6ImRpZmZlcl9hdF81ZmNjN2Q2MDYxZTdvb29vLmpzIiwiY2hlY2tzdW0iOjM0NzA0NjE2Mzd9LHsibmFtZSI6InZlbmRvcnN+YXV0aH5pbmRleH5sb2dpbn5zcGlkZXIiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InZlbmRvcnN+YXV0aH5pbmRleH5sb2dpbn5zcGlkZXJfYXRfNDAxNTMwNjQxZDgxb29vby5qcyIsImNoZWNrc3VtIjoyNzM2MTI4MH0seyJuYW1lIjoidmVuZG9yc35hdXRofmluZGV4fmxvZ2luIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJ2ZW5kb3JzfmF1dGh+aW5kZXh+bG9naW5fYXRfYjRhY2FlYWQ3ZGEyb29vby5qcyIsImNoZWNrc3VtIjoyMTI3MTgwMDl9LHsibmFtZSI6ImF1dGgiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6ImF1dGhfYXRfMGUzM2JjYzk1Nzhkb29vby5qcyIsImNoZWNrc3VtIjozNTg4MTM5MDI5fSx7Im5hbWUiOiJsb2dpbiIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoibG9naW5fYXRfZjkwZWRlZWNkY2Uxb29vby5qcyIsImNoZWNrc3VtIjoyMTE2NzM4NzZ9LHsibmFtZSI6ImluZGV4IiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJpbmRleF9hdF9jMDgyMWUxOWJiNjRvb29vLmpzIiwiY2hlY2tzdW0iOjMxNzU0NTYwODB9LHsibmFtZSI6InNwaWRlciIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoic3BpZGVyX2F0X2U4YTRiNDI0YzBiZG9vb28uanMiLCJjaGVja3N1bSI6MTQ3MjU1MTExNX0seyJuYW1lIjoid2hlcmVhbWktd2VpeGluIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJ3aGVyZWFtaS13ZWl4aW5fYXRfODBmZGFkOTA2M2Zlb29vby5qcyIsImNoZWNrc3VtIjoxMTYwNjA5NjIwfSx7Im5hbWUiOiJ3aGVyZWFtaS1rbmIiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6IndoZXJlYW1pLWtuYl9hdF8wYWMwYzBhODQxNmJvb29vLmpzIiwiY2hlY2tzdW0iOjQ2OTYzNjE3Nn0seyJuYW1lIjoidmVuZG9yc35kcGFwcH50aXRhbnMiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InZlbmRvcnN+ZHBhcHB+dGl0YW5zX2F0XzA2YjY0MmE0YzE2Nm9vb28uanMiLCJjaGVja3N1bSI6MjEwNDIzMDExOH0seyJuYW1lIjoidmVuZG9yc35kcGFwcCIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoidmVuZG9yc35kcGFwcF9hdF80ZDJiZDZiNWZmYzRvb29vLmpzIiwiY2hlY2tzdW0iOjMzNjAyMDA0N30seyJuYW1lIjoidmVuZG9yc35tdG5iIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJ2ZW5kb3Jzfm10bmJfYXRfNTQyMDE2NTg4Y2Izb29vby5qcyIsImNoZWNrc3VtIjoyNzEyODE3NTJ9LHsibmFtZSI6InZlbmRvcnN+aGJuYiIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoidmVuZG9yc35oYm5iX2F0XzUyYTE0ZWU4MmUwYW9vb28uanMiLCJjaGVja3N1bSI6MjA5MDc2NzkxNH0seyJuYW1lIjoid3giLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6Ind4X2F0XzBmYzBiZWFhOTJmOG9vb28uanMiLCJjaGVja3N1bSI6NzI2Mjg3OTk0fSx7Im5hbWUiOiJ0aXRhbnMiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InRpdGFuc19hdF85OTU0MzMwYTJiNTlvb29vLmpzIiwiY2hlY2tzdW0iOjE5NzE3NzEwOX0seyJuYW1lIjoidmVuZG9yc353aGVyZWFtaS1vd2wiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InZlbmRvcnN+d2hlcmVhbWktb3dsX2F0XzA1ZWQ3YTc3MjZkNm9vb28uanMiLCJjaGVja3N1bSI6MTkwODA3Mjc0fSx7Im5hbWUiOiJjb3Vwb25saXN0IiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJjb3Vwb25saXN0X2F0Xzg5M2VhNzdmYjM3OW9vb28uanMiLCJjaGVja3N1bSI6MTU4ODUwNDgwOX0seyJuYW1lIjoiZHBhcHAtc2hhcmUiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6ImRwYXBwLXNoYXJlX2F0XzM1ODRlZjI1ZjEyZG9vb28uanMiLCJjaGVja3N1bSI6MjY0NTQzMzM2fSx7Im5hbWUiOiJ3eC1zaGFyZSIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoid3gtc2hhcmVfYXRfNWI1YjlhMzBiYjE4b29vby5qcyIsImNoZWNrc3VtIjoyODQ0Njc4NDgwfSx7Im5hbWUiOiJ2ZW5kb3JzfnFxLXNoYXJlIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJ2ZW5kb3JzfnFxLXNoYXJlX2F0XzcyZDc0YzZlOGUzZG9vb28uanMiLCJjaGVja3N1bSI6MTkwMzI5NDkxNn0seyJuYW1lIjoicXF6b25lLXNoYXJlIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJxcXpvbmUtc2hhcmVfYXRfMGNjMTMxM2RmZTg4b29vby5qcyIsImNoZWNrc3VtIjoyOTQ1ODQzODQxfSx7Im5hbWUiOiJtdC1zaGFyZSIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoibXQtc2hhcmVfYXRfMGQ5NDgwY2I1NzY4b29vby5qcyIsImNoZWNrc3VtIjozOTgxNzM0MTg3fSx7Im5hbWUiOiJicm93c2VyLXNoYXJlIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJicm93c2VyLXNoYXJlX2F0X2IwMzBiZmYyZjlkM29vb28uanMiLCJjaGVja3N1bSI6MzA2MTE3OTc4fSx7Im5hbWUiOiJ2ZW5kb3JzfmJyYW5kbGlzdH5vcmRlcmRldGFpbCIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoidmVuZG9yc35icmFuZGxpc3R+b3JkZXJkZXRhaWxfYXRfOTdlYWViMzZkYTljb29vby5qcyIsImNoZWNrc3VtIjoxOTQwMTUxNDY3fSx7Im5hbWUiOiJicmFuZGxpc3QiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6ImJyYW5kbGlzdF9hdF9mNjMyYzI4ZTczMDJvb29vLmpzIiwiY2hlY2tzdW0iOjE3MzY2NzU2MzB9LHsibmFtZSI6InBvaSIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoicG9pX2F0XzA1YzhhOWVkZDEyMW9vb28uanMiLCJjaGVja3N1bSI6MTAzMzI5OTUzOX0seyJuYW1lIjoidmVuZG9yc35ob21lfmtpbmdrb25nfnJlZnVuZG9yZGVyIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJ2ZW5kb3JzfmhvbWV+a2luZ2tvbmd+cmVmdW5kb3JkZXJfYXRfMGQ3MjU5MWUxODkzb29vby5qcyIsImNoZWNrc3VtIjoxOTIzODU5OTk5fSx7Im5hbWUiOiJyZWZ1bmRvcmRlciIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoicmVmdW5kb3JkZXJfYXRfOGYzZjExNDYyOWZmb29vby5qcyIsImNoZWNrc3VtIjo1MDM4MTkzNX0seyJuYW1lIjoidmVuZG9yc35wcmV2aWV3fnJlZnVuZHByb2Nlc3MiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InZlbmRvcnN+cHJldmlld35yZWZ1bmRwcm9jZXNzX2F0X2JhYWM4NWY0MGQ0Nm9vb28uanMiLCJjaGVja3N1bSI6NjQ0MDQ5ODh9LHsibmFtZSI6InJlZnVuZHByb2Nlc3MiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InJlZnVuZHByb2Nlc3NfYXRfZDRiNDliODdkZTMzb29vby5qcyIsImNoZWNrc3VtIjoxMjE3NDc4Mjg3fSx7Im5hbWUiOiJvcmRlcmRldGFpbH5vcmRlcmZsb3ciLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6Im9yZGVyZGV0YWlsfm9yZGVyZmxvd19hdF8wYjkyOTE0NTAwOGJvb29vLmpzIiwiY2hlY2tzdW0iOjIzNzc5OTMzNjZ9LHsibmFtZSI6Im9yZGVyZmxvdyIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoib3JkZXJmbG93X2F0XzQ0MWQzZGQ1OTUwMm9vb28uanMiLCJjaGVja3N1bSI6MTU3OTk2NDgxMn0seyJuYW1lIjoidmVuZG9yc35vcmRlcmRldGFpbH5vcmRlcmxpc3R+cHJldmlldyIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoidmVuZG9yc35vcmRlcmRldGFpbH5vcmRlcmxpc3R+cHJldmlld19hdF9lNzk5ZDE2NWFhYzZvb29vLmpzIiwiY2hlY2tzdW0iOjE0NzcwOTIyMzZ9LHsibmFtZSI6InZlbmRvcnN+b3JkZXJkZXRhaWwiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InZlbmRvcnN+b3JkZXJkZXRhaWxfYXRfNGMzZDdhNDE2NjAwb29vby5qcyIsImNoZWNrc3VtIjoxMTk2MzU1MzB9LHsibmFtZSI6Im9yZGVyZGV0YWlsIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJvcmRlcmRldGFpbF9hdF9kODQ4MmMzNzA0OTFvb29vLmpzIiwiY2hlY2tzdW0iOjMxMDk4OTc3NDJ9LHsibmFtZSI6Im1pbmUiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6Im1pbmVfYXRfNGQxZjdmZTczYTA0b29vby5qcyIsImNoZWNrc3VtIjozMTY0MTA4OTgzfSx7Im5hbWUiOiJvcmRlcmxpc3QiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6Im9yZGVybGlzdF9hdF83NjBlNDc0YTY0OWJvb29vLmpzIiwiY2hlY2tzdW0iOjIwMzg2Nzc2NjZ9LHsibmFtZSI6Im1lbnV+cHJldmlldyIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoibWVudX5wcmV2aWV3X2F0XzJhYzc0MjMyZDVkMG9vb28uanMiLCJjaGVja3N1bSI6NTc0MDUwMDUyfSx7Im5hbWUiOiJwcmV2aWV3IiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJwcmV2aWV3X2F0XzU2YWYxNGEyMjIyY29vb28uanMiLCJjaGVja3N1bSI6Mjk2MTY3MDg0Nn0seyJuYW1lIjoic3RhdGljLWNvcnRleF9tb2R1bGVzLUBjb3J0ZXgtd20tY29tcG9uZW50LXByb21vZGVzay1zcmMtcHJvbW8tZGVzay1qcyIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoic3RhdGljLWNvcnRleF9tb2R1bGVzLUBjb3J0ZXgtd20tY29tcG9uZW50LXByb21vZGVzay1zcmMtcHJvbW8tZGVzay1qc19hdF9iOWVhYmM0MjcxM2Fvb29vLmpzIiwiY2hlY2tzdW0iOjM2NjMxNzE5MDF9LHsibmFtZSI6Im5vZGVfbW9kdWxlcy10aW1lcnMtYnJvd3NlcmlmeS1tYWluLWpzIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJub2RlX21vZHVsZXMtdGltZXJzLWJyb3dzZXJpZnktbWFpbi1qc19hdF8wZTc3ZDUxYTcyMDhvb29vLmpzIiwiY2hlY2tzdW0iOjQxOTE4MTU0MjZ9LHsibmFtZSI6InZlbmRvcnN+bWVudX5wb2lwaWNrZXJ+cG9pcGlja2VyY2l0eSIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoidmVuZG9yc35tZW51fnBvaXBpY2tlcn5wb2lwaWNrZXJjaXR5X2F0XzQzM2QyODI5YThlMG9vb28uanMiLCJjaGVja3N1bSI6MzYwODkwOTk4N30seyJuYW1lIjoidmVuZG9yc35tZW51IiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJ2ZW5kb3Jzfm1lbnVfYXRfZWY4Yzg4YTNiYjg5b29vby5qcyIsImNoZWNrc3VtIjozNDIzMzg0OTg0fSx7Im5hbWUiOiJtZW51IiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJtZW51X2F0XzU0MzFkMmU4YjZkNm9vb28uanMiLCJjaGVja3N1bSI6MzE1MjIwMDA5N30seyJuYW1lIjoidmVuZG9yc35ob21lfmtpbmdrb25nIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJ2ZW5kb3JzfmhvbWV+a2luZ2tvbmdfYXRfMTBjNmU3NzAzMWQ0b29vby5qcyIsImNoZWNrc3VtIjo3ODI4ODk1OTl9LHsibmFtZSI6ImhvbWV+a2luZ2tvbmciLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6ImhvbWV+a2luZ2tvbmdfYXRfZDgwNzVjNzk1ZGMyb29vby5qcyIsImNoZWNrc3VtIjoxMDU4NTQ3MTQyfSx7Im5hbWUiOiJob21lIiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJob21lX2F0Xzc1ZWM0N2YwZTUwZW9vb28uanMiLCJjaGVja3N1bSI6MzQ1MDk5MzMxfSx7Im5hbWUiOiJiYW5uZXIiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6ImJhbm5lcl9hdF80YzNiNTdmZmU0NjNvb29vLmpzIiwiY2hlY2tzdW0iOjExMzY0NjU4Mjd9LHsibmFtZSI6ImFkZGFkZHJlc3MiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6ImFkZGFkZHJlc3NfYXRfNzA2MTY1YTljMDZjb29vby5qcyIsImNoZWNrc3VtIjoxNjIyMTk0NDA3fSx7Im5hbWUiOiJhZGRyZXNzbGlzdCIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoiYWRkcmVzc2xpc3RfYXRfYTExYjU0N2EyYTI3b29vby5qcyIsImNoZWNrc3VtIjozNTAzNzU4Nzc3fSx7Im5hbWUiOiJraW5na29uZyIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoia2luZ2tvbmdfYXRfMmI4NWRjOWM5Mjc4b29vby5qcyIsImNoZWNrc3VtIjoxOTc2MzM3M30seyJuYW1lIjoic2VhcmNocmVzdWx0IiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJzZWFyY2hyZXN1bHRfYXRfNzAyMjQ0YjU2NmZlb29vby5qcyIsImNoZWNrc3VtIjoyODExNjgwNTczfSx7Im5hbWUiOiJzZWFyY2giLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InNlYXJjaF9hdF8zMmVlM2IxNGRmMDVvb29vLmpzIiwiY2hlY2tzdW0iOjEyMDIwOTgzMjZ9LHsibmFtZSI6Imdlb2ZhaWwiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6Imdlb2ZhaWxfYXRfNzNlNGE4OWM0NDU1b29vby5qcyIsImNoZWNrc3VtIjozOTE1ODY4MDI2fSx7Im5hbWUiOiJwb2lwaWNrZXJ+cG9pcGlja2VyY2l0eSIsInR5cGUiOiJqcyIsImZpbGVuYW1lIjoicG9pcGlja2VyfnBvaXBpY2tlcmNpdHlfYXRfMmFjNTUxMzUxOTU1b29vby5qcyIsImNoZWNrc3VtIjoxNjU3NjY1MjE2fSx7Im5hbWUiOiJwb2lwaWNrZXJjaXR5IiwidHlwZSI6ImpzIiwiZmlsZW5hbWUiOiJwb2lwaWNrZXJjaXR5X2F0X2YzZjQ2OTRmODFmNG9vb28uanMiLCJjaGVja3N1bSI6MTI3ODA0MTgwfSx7Im5hbWUiOiJwb2lwaWNrZXIiLCJ0eXBlIjoianMiLCJmaWxlbmFtZSI6InBvaXBpY2tlcl9hdF85YjFhMGMyY2U3Yzdvb29vLmpzIiwiY2hlY2tzdW0iOjk3NjA3MjU3OH1dLCJjb21waWxhdGlvbiI6eyJoYXNoIjoiMDQxMGE2MDhhMzQ1MjUwNmVmM2MiLCJmdWxsSGFzaCI6IjA0MTBhNjA4YTM0NTI1MDZlZjNjYjRiZmNkODJkZjQxIn0sInByb2plY3QiOiI5MDk2ZDM0NyIsImNhY2hlQWdlIjowLCJTdGFya09wdGlvbnMiOnsicHJvamVjdE5hbWUiOiI5MDk2ZDM0NyIsImRpc3QiOiIvdG1wL2J1aWxkL3NyYy9zdGF0aWMvYnVpbGQifSwic2VydmljZVdvcmtlciI6eyJwYXRoIjoiL3RodW5kZXIuc3cuanMiLCJzY29wZSI6Ii8iLCJzdHJhdGVnaWVzIjp7IkNhY2hlRmlyc3QiOnsiaW5jbHVkZXMiOlsicDFcXC5tZWl0dWFuXFwubmV0Iiwic3RhdGljXFwubWVpdHVhblxcLm5ldCIsInMzcGx1c1xcLnNhbmt1YWlcXC5jb20iXX19fSwib3V0cHV0T3B0aW9ucyI6eyJwdWJsaWNQYXRoIjoiLy9zM3BsdXMubWVpdHVhbi5uZXQvdjEvbXNzX2UyODIxZDdmMGNmZTRhYzFiZjkyMDJlY2Y5NTkwZTY3L2Nkbi1wcm9kL2ZpbGU6OTA5NmQzNDcvIiwiY3Jvc3NPcmlnaW5Mb2FkaW5nIjpmYWxzZSwiY2h1bmtMb2FkVGltZW91dCI6MTIwMDAwLCJmYWxsYmFja0NETiI6Ii8vczNwbHVzLm1laXR1YW4ubmV0L3YxL21zc19lMjgyMWQ3ZjBjZmU0YWMxYmY5MjAyZWNmOTU5MGU2Ny9jZG4tcHJvZC9maWxlOjkwOTZkMzQ3LyIsImNoZWNrc3VtIjp0cnVlLCJsaWJyYXJ5IjoiIiwiaG90VXBkYXRlRnVuY3Rpb24iOiJ3ZWJwYWNrSG90VXBkYXRlIiwianNvbnBGdW5jdGlvbiI6IndlYnBhY2tKc29ucCIsInRodW5kZXJGaWxlbmFtZSI6IiJ9fQ=="))
    } catch (e) {
        console.error("ERROR at parsing thunderStateServiceWorkerOptions: ", e)
    }
    var $ = new L;
    $.init(N), self.serviceWorkerRuntime = $, self.addEventListener("install", function (e) {
        $._initJob ? e.waitUntil($._initJob.then(function () {
            return self.skipWaiting()
        })) : e.waitUntil(self.skipWaiting())
    }), self.addEventListener("activate", function (e) {
        e.waitUntil(self.clients.claim())
    }), self.addEventListener("message", $.messageHandler), self.addEventListener("fetch", $.fetchHandler)
}();
