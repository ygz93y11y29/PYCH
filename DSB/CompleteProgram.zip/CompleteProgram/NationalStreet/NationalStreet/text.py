


print({}.values())

print(type({}))