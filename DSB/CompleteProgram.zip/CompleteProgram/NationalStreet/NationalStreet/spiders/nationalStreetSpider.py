# -*- coding: utf-8 -*-
import scrapy
import json


class NationalstreetspiderSpider(scrapy.Spider):
    name = 'nationalStreetSpider'
    allowed_domains = ['map.51240.com']
    start_urls = []

    def start_requests(self):
        url = 'https://map.51240.com/web_system/51240_com_www/system/file/map/duqu/'
        data = {
            'root':'id_qq_1',
            'additional':'yeah: Fri Jun 19 2020 12:57:08 GMT+0800 (中国标准时间)'
        }
        yield scrapy.FormRequest(url=url, formdata=data)


    def parse(self, response):
        # print(response.text)
        jsonDataList = json.loads(response.text)
        for jsonData in jsonDataList[3:]:
            id = jsonData.get('id')
            classes = jsonData.get('classes')
            provinceText = jsonData.get('text')
            cityUrl = 'https://map.51240.com/web_system/51240_com_www/system/file/map/duqu/'
            cityData = {
                'root':id,
                'additional':'yeah: Fri Jun 19 2020 12:57:08 GMT+0800 (中国标准时间)'
            }
            yield scrapy.FormRequest(url=cityUrl, meta={'provinceText':provinceText}, formdata=cityData, callback=self.cityParse)
            break

    def cityParse(self, response):
        # print(response.text)
        provinceText = response.meta["provinceText"]
        jsonDataList = json.loads(response.text)
        for jsonData in jsonDataList:
            id = jsonData.get('id')
            classes = jsonData.get('classes')
            cityText = jsonData.get('cityText')
            # print("******",cityText, id, classes, cityText)
            areaUrl = 'https://map.51240.com/web_system/51240_com_www/system/file/map/duqu/'
            areaData = {
                'root':id,
                'additional':'yeah: Fri Jun 19 2020 13:15:42 GMT+0800 (中国标准时间)'
            }
            yield scrapy.FormRequest(url=areaUrl, meta={'provinceText':provinceText, 'cityText':cityText}, formdata=areaData, callback=self.areaParse)
            break

    def areaParse(self, response):
        provinceText = response.meta['provinceText']
        cityText = response.meta['cityText']
        jsonDataList = json.loads(response.text)
        # print("****",jsonDataList)
        # print("---", type(jsonDataList))
        if type(jsonDataList) == type({}):
            jsonDataList = jsonDataList.values()
        for jsonData in jsonDataList:
            id = jsonData.get('id')
            classes = jsonData.get('classes')
            areaPText = jsonData.get('text')
            # print(cityText, areaPText, id, classes, text)
            areaUrl = 'https://map.51240.com/web_system/51240_com_www/system/file/map/duqu/'
            areaData = {
                'root':id,
                'additional':'yeah: Fri Jun 19 2020 13:15:42 GMT+0800 (中国标准时间)'
            }
            yield scrapy.FormRequest(url=areaUrl, meta={'provinceText':provinceText, 'cityText':cityText, 'areaPText':areaPText}, formdata=areaData, callback=self.streetParse)
            break

    def streetParse(self, response):
        provinceText = response.meta['provinceText']
        cityText = response.meta['cityText']
        areaPText = response.meta['areaPText']
        print('provinceText',provinceText)
        print('cityText',cityText)
        print('areaPText', areaPText)

        jsonDataList = json.loads(response.text)
        for jsonData in jsonDataList:
            id = jsonData.get('id')
            streetText = jsonData.get('classes')
            text = jsonData.get('text')
            print(provinceText, cityText, areaPText, streetText)






