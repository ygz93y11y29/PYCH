# coding:utf8
import datetime
import time
import threading

def doSth():
    # 把爬虫程序放在这个类里
    print(u'这个程序要开始疯狂的运转啦')


# 一般网站都是1:00点更新数据，所以每天凌晨一点启动
def main(h=1, m=0):
    while True:
        now = datetime.datetime.now()
        # print(now.hour, now.minute)
        if now.hour == h and now.minute == m:
            doSth()
        # 每隔60秒检测一次
        time.sleep(60)

#3.
def func():
    print("haha")
    # 如果需要循环调用，就要添加以下方法
    timer = threading.Timer(86400, func)
    timer.start()

# 获取现在时间
now_time = datetime.datetime.now()
# 获取明天时间
next_time = now_time + datetime.timedelta(days=+1)
next_year = next_time.date().year
next_month = next_time.date().month
next_day = next_time.date().day
# 获取明天3点时间
next_time = datetime.datetime.strptime(str(next_year) + "-" + str(next_month) + "-" + str(next_day) + " 03:00:00",
                                       "%Y-%m-%d %H:%M:%S")
# # 获取昨天时间
# last_time = now_time + datetime.timedelta(days=-1)

# 获取距离明天3点时间，单位为秒
timer_start_time = (next_time - now_time).total_seconds()
print(timer_start_time)
# 54186.75975


# 定时器,参数为(多少时间后执行，单位为秒，执行的方法)
timer = threading.Timer(timer_start_time, func)


if __name__ == '__main__':
    main()