# -*- coding:utf-8 -*-
import os
import sys
import requests
from lxml import etree
import datetime
import time
import json
from Server import ServerClass
from setting import SPIDER_TIME
from log import logClass


class xinHuaNetClass(object):
    def __init__(self):
        self.SQL = ServerClass()
        self.LOG = logClass('xinHuaNet_spider')

    def req_xinHuaNet(self, url):
        '''
            发送请求
        :return:  返回请求的response.text
        '''
        header = {
            'user-agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Mobile Safari/537.36',
        }
        try:
            response =  requests.get(url=url, headers = header)
            if response.status_code == 200:
                response.encoding = 'UTF-8-SIG'
                nmb =self.parse(response.text)
                return nmb
            else:
                return False
        except Exception as error:
            self.LOG.print_error("req_fsamrFoshanGov error !  {}".format(error))
            return False

    def req_contentTitle(self, sourceURL, title, createtime, imageurl, abstract):
        '''
            发送请求
        :return:  返回请求的response.text
        '''
        header = {
            'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
        }
        try:
            response =  requests.get(url=sourceURL, headers = header)
            if response.status_code == 200:
                response.encoding = 'UTF-8-SIG'
                self.parse_contentTitle(response.text,sourceURL, title, createtime, imageurl, abstract)
        except Exception as error:
            self.LOG.print_error("req_contentTitle error ! {}".format(error))

    def parse(self, response):
        '''
            解析列表页
        :return:
        '''
        try:
            delsing = response.split('({')[0] + '('
            strduct = response.replace(delsing, '').replace(')', '').replace(delsing, '')
            jsondata = json.loads(strduct)
            data = jsondata.get("data")
            List = data.get("list")
            for lis in List:
                title = lis.get("Title")
                createtime = lis.get("PubTime")
                sourceURL = lis.get("LinkUrl")
                if len(lis.get("allPics")) > 0:
                    imageurl = lis.get("allPics")[0]
                else:
                    imageurl = ''
                abstract = lis.get("Abstract")
                spiderTime = SPIDER_TIME
                publishTime = datetime.datetime.strptime(createtime, "%Y-%m-%d %H:%M:%S")
                TimeSpan = (spiderTime - publishTime).days
                if TimeSpan > 1:
                    return 1
                self.req_contentTitle(sourceURL, title, createtime, imageurl, abstract)
                time.sleep(2)
            time.sleep(2)
            return len(List)
        except Exception as error:
            self.LOG.print_error("parse error !  {}".format(error))
            return False

    def parse_contentTitle(self, response, sourceURL, title, createtime, imageurl, abstract):
        '''
                解析详情页的信息
        :param response:  response.text
        :param title: 文章的标题
        :param sourceURL:  文章的url
        :param createtime:  文章的发表时间，只有时分秒
        :return:
        '''
        try:
            sourceurl = sourceURL
            base_image_url = '/'.join(sourceurl.split('/')[:-1]) + '/'
            response = etree.HTML(response)
            Element0 = response.xpath('//div[@id="p-detail"]')
            Element1 = response.xpath('//div[@class="con_txt"]')
            if len(Element0) > 0:
                # 替换img的src链接不全：如src="1125797727_15857056179341n.jpg"
                outcontent = etree.tostring(Element0[0], encoding="utf-8", pretty_print=True, method="html").decode().replace('./', base_image_url).replace(' ', ' ')
                listImgList = Element0[0].xpath('.//img/@src')
                for imgS in listImgList:
                    if 'http' not in imgS:
                        imgSrc = base_image_url + imgS
                        outcontent = outcontent.replace(imgS, imgSrc)
            elif len(Element1) > 0:
                # 替换img的src链接不全：如src="1125797727_15857056179341n.jpg"
                outcontent = etree.tostring(Element1[0], encoding="utf-8", pretty_print=True, method="html").decode().replace('./', base_image_url).replace(' ', ' ')
                listImgList = Element1[0].xpath('.//img/@src')
                for imgS in listImgList:
                    if 'http' not in imgS:
                        imgSrc = base_image_url + imgS
                        outcontent = outcontent.replace(imgS, imgSrc)
            else:
                outcontent = ''

            #去掉图集，在源码中隐藏掉
            outcontent = outcontent.replace('class="standard_lb"', 'class="standard_lb" style="display:none"')

            title = title
            createtime = createtime
            createtime = datetime.datetime.now()
            imageurl = imageurl
            abstract = abstract
            contentcodetype = 'u'
            abstractcodetype = 'u'
            configid = 128
            categoryid = 1208
            host = 'http://www.xinhuanet.com'
            listurl = 'http://www.xinhuanet.com/food/sppy/qwpy.htm'
            believeable = 1
            weight = 0
            #print(imageurl)
            data = (title,sourceurl,createtime,imageurl,outcontent,contentcodetype,abstract,abstractcodetype,configid,categoryid,host,listurl,believeable,weight)
            self.LOG.print_info("data  :  {}".format(str(title) + str(sourceURL)))
            self.SQL.insert_FSoutsourceingcollection(data, self.LOG)
        except Exception as error:
            self.LOG.print_error("parse_contentTitle error ! {}".format(error))

    def qwpyURL_run(self, timeStr):
        '''
                辟谣爬虫调度
        :return:
        '''
                       #http://qc.wa.news.cn/nodeart/list?nid=11148362&pgnum={}&cnt=10&tp=1&orderby=1?callback=jQuery1124043093941756100995_{}&_={}
        base_qwpyURL = 'http://qc.wa.news.cn/nodeart/list?nid=11148362&pgnum={}&cnt=10&tp=1&orderby=1?callback=jQuery1124043093941756100995_{}&_={}'
        i = 1
        while True:
            qwpyURL = base_qwpyURL.format(i,timeStr,timeStr)
            self.LOG.print_info("qwpyURL : {}".format( qwpyURL))
            nmb = FS.req_xinHuaNet(qwpyURL)
            if nmb == 10:
                i = i + 1
            if nmb < 10:
                break


    def zzsURL_run(self, timeStr):
        '''
                长知识爬虫调度
        :return:
        '''
                      #http://qc.wa.news.cn/nodeart/list?nid=11148367&pgnum={}&cnt=10&tp=1&orderby=1?callback=jQuery11240579901844354128_{}&_={}
        base_zzsURL = 'http://qc.wa.news.cn/nodeart/list?nid=11148367&pgnum={}&cnt=10&tp=1&orderby=1?callback=jQuery11240579901844354128_{}&_={}'
        i = 1
        while True:
            zzsURL = base_zzsURL.format(i,timeStr,timeStr)
            self.LOG.print_info("zzsURL : {}".format(zzsURL))
            nmb = FS.req_xinHuaNet(zzsURL)
            if nmb == 10:
                i = i + 1
            if nmb < 10:
                break


    def run(self):
        '''
            控制爬虫的启动
        :return:
        '''
        timeStr = str(time.time())[:14].replace('.', '')
        self.qwpyURL_run(timeStr)

        self.zzsURL_run(timeStr)
        self.SQL.DBclose()
        print("****************OK*********")


if __name__ == '__main__':
    FS = xinHuaNetClass()
    FS.run()




