﻿# -*- coding:utf-8 -*-
import pymssql
import datetime


class ServerClass(object):
    '''
        Server的操作类
    '''
    def __init__(self):
        #self.db = pymssql.connect(database="OutSource", user="out_conn", password="I3mtc3`iKSf!Uu.I04XD", host="127.0.0.1",charset="utf8")
        self.db = pymssql.connect(database="RPT_DB_V3", user="rip_conn", password="1234QWER!@#$", host="192.168.9.180", charset="utf8")
        self.cursor = self.db.cursor()

    def insert_FSoutsourceingcollection(self, data, LOG):
        '''
            向MTActualLicense表中插入数据
        :param data: 元组    来之pase.py
        :return:
        '''
        try:
            #(title, sourceurl, createtime, imageurl, outcontent, contentcodetype, abstract, abstractcodetype,configid, categoryid, host, listurl, believeable, weight)

            sql =  "INSERT INTO outsourceingcollection (title, sourceurl, createtime, imageurl, outcontent, contentcodetype, abstract, abstractcodetype,configid, categoryid, host, listurl, believeable, weight) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            #sql = "INSERT INTO app_spider_ELArea ([key],province,citycode,city,district,street,shoplatitude,shoplongitude,data_insert) VALUES ('8a09a7e2a37dc70598739597e5dcbfe8', '浙江省', '0572', '湖州市', '吴兴区', '衣裳街', '120.099910', '30.862549', '2019-08-13 11:20:40.730')"
            #print(sql)
            self.cursor.execute(sql,data)
            self.db.commit()
            LOG.print_info("insert_FSoutsourceingcollection success !")
            return True
        except Exception as error:
            self.LOG.print_error('insert_FSoutsourceingcollection', error)
            return False

    def select_text(self,sql):
        try:
            #sql =  "select * from dbo.outsourceingcollection where title like '%佛山市市场监督管理局关于外国（地区）企业常驻代表机构提交2018年度报告的通告%'"

            self.cursor.execute(sql)
            rows = self.cursor.fetchall()
            # self.db.commit()
            # print("select success !")
            if len(rows) == 0:
                return False
            else:
                return rows
        except Exception as error:
            print(' ', error)

    def DBclose(self):
        self.db.close()

if __name__ == '__main__':
    SQL = ServerClass()
    sql = 'select distinct md5key from [dbo].[ods_spider_MTmtshopChangsha]'

    list1 = []
    rows = [i[0] for i in SQL.select_text(sql)]
    print(tuple(rows))
    print(len(rows))


