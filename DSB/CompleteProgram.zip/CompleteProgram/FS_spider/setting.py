﻿import datetime
#爬取前一天的
SPIDER_TIME = datetime.datetime.now()
#爬取全部
#SPIDER_TIME = datetime.datetime.strptime('2020-04-17 00:00:00', "%Y-%m-%d %H:%M:%S")




