# -*- coding:utf-8 -*-
import requests
from lxml import etree
import datetime
import time
from Server import ServerClass
from setting import SPIDER_TIME
from log import logClass

class fsamrFoshanGovClass(object):
    def __init__(self):
        self.SQL = ServerClass()
        self.LOG = logClass('fsamrFoshanGov_spider')

    def req_fsamrFoshanGov(self, url):
        '''
            发送请求
        :return:  返回请求的response.text
        '''
        header = {
            'user-agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Mobile Safari/537.36',
        }
        try:
            response =  requests.get(url=url, headers = header)
            if response.status_code == 200:
                response.encoding = 'UTF-8-SIG'
                nmb = self.parse(response.text)
                return nmb
            else:
                return False
        except Exception as error:
            self.LOG.print_error("req_fsamrFoshanGov error ! {}".format(error))
            return False

    def req_contentTitle(self, sourceURL, title, createtime):
        '''
            发送请求
        :return:  返回请求的response.text
        '''
        header = {
            'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        }
        try:
            response =  requests.get(url=sourceURL, headers = header)
            #print(sourceURL)
            if response.status_code == 200:
                response.encoding = 'UTF-8-SIG'
                self.parse_contentTitle(response.text,title,sourceURL, createtime)
        except Exception as error:
            self.LOG.print_error("req_contentTitle error ! {}".format(error))

    def parse(self, response):
        '''
            解析列表页
        :return:
        '''
        try:
            response = etree.HTML(response)
            liList = response.xpath('//div[@class="news_list"]/ul/li')
            for li in liList:
                hrefURL = li.xpath('./a/@href')[0]
                title = li.xpath('./a/@title')[0]
                createtime = li.xpath('./span/text()')[0]
                baseURL = "http://fsamr.foshan.gov.cn/zwdt/tzgg/"
                sourceURL = hrefURL
                #sourceURL = baseURL + hrefURL.strip('./')
                spiderTime = SPIDER_TIME#当前时间
                publishTime = datetime.datetime.strptime(createtime, "%Y-%m-%d")#发布时间
                #spiderTime 截至时间
                #publishTime 网页时间
                TimeSpan = (spiderTime-publishTime).days

                if TimeSpan<2 and TimeSpan!=0:
                    self.req_contentTitle(sourceURL, title, createtime)
                    time.sleep(1)
            time.sleep(2)
            return len(liList)
        except Exception as error:
            self.LOG.print_error("parse error ! {}".format(error))
            return False

    def parse_contentTitle(self, response, title, sourceURL, createtime):
        '''
                解析详情页的信息
        :param response:  response.text
        :param title: 文章的标题
        :param sourceURL:  文章的url
        :param createtime:  文章的发表时间，只有时分秒
        :return:
        '''
        try:
                response = etree.HTML(response)
                sourceurl = sourceURL
                base_image_url = '/'.join(sourceurl.split('/')[:-1]) + '/'
                if len(response.xpath('//span[@class="time"]/b/text()')) == 0:
                    createtime = createtime
                else:
                    createtime = response.xpath('//span[@class="time"]/b/text()')[0].strip('\n').strip()
                createtime = datetime.datetime.now()
                #content = response.xpath('//div[@class="TRS_Editor"]')
                content = response.xpath('//div[@class="content_article"]')
                if len(content)==0:
                    content = response.xpath('//div[@class="TRS_Editor"]')
                if len(content) > 0:
                    outcontent = etree.tostring(content[0], encoding="utf-8", pretty_print=True, method="html").decode().replace('./', base_image_url).replace(' ', ' ')#replace('&nbsp;', " ")
                    base_abstract = response.xpath('//div[@class="TRS_Editor"]//p/span//text()')
                    if len(base_abstract)<1:
                        base_abstract = response.xpath('//div[@class="content_article"]//text()')

                    abstract= ''.join(base_abstract).strip('')[:50]
                    # http://fsamr.foshan.gov.cn/zwdt/tzgg/201909/W020190919355743121699.jpg
                    base_imageurl = '/'.join(sourceurl.split('/')[:-1])
                    if len(response.xpath('//div[@class="content_article"]//img/@src')) != 0:
                        imageurl = response.xpath('//div[@class="content_article"]//img/@src')[0].strip('./')
                        #print(imageurl)
                    else:
                        imageurl = ''
                    contentcodetype = 'u'
                    abstractcodetype = 'u'
                    configid = 126
                    categoryid = 1206
                    host = 'fsamr.foshan.gov.cn'
                    listurl = 'http://fsamr.foshan.gov.cn/zwdt/tzgg/'
                    believeable = 1
                    weight = 0
                    data = (title, sourceurl, createtime, imageurl, outcontent, contentcodetype, abstract, abstractcodetype,configid, categoryid, host, listurl, believeable, weight)
                    self.LOG.print_info("data  :  {}".format(str(title) +str(sourceURL)))
                    self.SQL.insert_FSoutsourceingcollection(data, self.LOG)
        except Exception as error:
            print("*********")
            self.LOG.print_error("parse_contentTitle error ! {}".format(error))


    def run(self):
        '''
            控制爬虫的启动
        :return:
        '''
        for i in range(1):
            self.LOG.print_info('i : {}'.format(i))
            if i == 0:
                url = 'http://fsamr.foshan.gov.cn/zwdt/tzgg/index.html'
                nmb = self.req_fsamrFoshanGov(url)
                if nmb == 1:
                    break
            else:
                url = 'http://fsamr.foshan.gov.cn/zwdt/tzgg/index_{}.html'.format(i)
                self.LOG.print_info("url : {}".format(url))
                nmb = self.req_fsamrFoshanGov(url)
                if nmb == 1:
                    break
                time.sleep(3)
        #self.SQL.DBclose()
        print("****************OK*********")

if __name__ == '__main__':
    FS = fsamrFoshanGovClass()
    FS.run()



