# -*- coding:utf-8 -*-
import requests
from lxml import etree
import datetime
import time
from Server import ServerClass
from setting import SPIDER_TIME
from log import logClass
import io
import sys
import urllib.request
#sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf8') #改变标准输出的默认编码

class fsjyNetClass(object):
    def __init__(self):
        self.SQL = ServerClass()
        self.LOG = logClass('fsjyNet_spider')

    def req_fsjyNet(self, url):
        '''
            发送请求
        :return:  返回请求的response.text
        '''
        header = {
            'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        }
        try:
            response =  requests.get(url=url, headers = header)
            if response.status_code == 200:
                response.encoding = 'UTF-8-SIG'
                nmb = self.parse(response.text)
                return nmb
            else:
                return False
        except Exception as error:
            self.LOG.print_error("req_fsamrFoshanGov error !    {}".format(error))
            return False

    def req_contentTitle(self, title, sourceURL, createtime):
        '''
            发送请求
        :return:  返回请求的response.text
        '''
        header = {
            'user-agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Mobile Safari/537.36',
        }
        try:
            response =  requests.get(url=sourceURL, headers = header)
            if response.status_code == 200:
                response.encoding = 'UTF-8-SIG'
                self.parse_contentTitle(response.text, title, sourceURL, createtime)
        except Exception as error:
            self.LOG.print_error("req_contentTitle error ! {}".format(error))

    def parse(self, response):
        '''
            解析列表页
        :return:
        '''
        try:
            response = etree.HTML(response)
            ulList = response.xpath('//div[@class="listbox"]/ul')
            for ul in ulList:
                liList = ul.xpath('./li')
                for li in liList:
                    # http://edu.foshan.gov.cn/kx/jjkx/201909/t20190920_7566191.html
                    hrefURL = li.xpath('./a/@href')[0]
                    title = li.xpath('./a//text()')[0]
                    createtime = li.xpath('.//text()')[1].replace('[','').replace(']','')
                    baseURL = r"http://edu.foshan.gov.cn/kx/jjkx/"
                    if 'http' not in hrefURL:
                        sourceURL = baseURL + hrefURL.strip('./')
                    else:
                        sourceURL = hrefURL
                    spiderTime = SPIDER_TIME
                    publishTime = datetime.datetime.strptime(createtime, "%Y-%m-%d")
                    TimeSpan = (spiderTime - publishTime).days
                    if TimeSpan > 1:
                        return False
                    self.req_contentTitle(title, sourceURL, createtime)
                    time.sleep(1)
                time.sleep(2)
            return len(ulList)
        except Exception as error:
            self.LOG.print_error("parse error ! {}".format(error))
            return False


    def parse_contentTitle(self, response, title, sourceURL, createtime):
        '''
                解析详情页的信息
        :param response:  response.text
        :param title: 文章的标题
        :param sourceURL:  文章的url
        :param createtime:  文章的发表时间，只有时分秒
        :return:
        '''
        try:
            response = etree.HTML(response)
            sourceurl = sourceURL
            base_image_url = '/'.join(sourceurl.split('/')[:-1]) + '/'
            des = response.xpath('//div[@class="des"]/span/text()')
            if len(des) > 3:
                if "发表时间：" in des[2]:
                    createtime = des[2].replace("发表时间：", "")
            createtime = datetime.datetime.now()
            content = response.xpath('//div[@class="TRS_Editor"]')
            if len(content) > 0:
                outcontent = etree.tostring(content[0], encoding="utf-8", pretty_print=True, method="html").decode().replace('./', base_image_url).replace(' ', ' ')

                base_abstract = response.xpath('//div[@class="TRS_Editor"]//p//text()')
                abstract = ''.join(base_abstract).strip('')[:50]
                base_imageurl = base_image_url
                if len(content[0].xpath('.//img/@src')) != 0:
                    imageurl = content[0].xpath('.//img/@src')[0].strip('./')
                    #print(imageurl)
                else:
                    imageurl = ''
                contentcodetype = 'u'
                abstractcodetype = 'u'
                configid = 127
                categoryid = 1207
                host = 'www.fsjy.net/'
                listurl = 'http://edu.foshan.gov.cn/kx/jjkx/'
                believeable = 1
                weight = 0
                data = (title, sourceurl, createtime, imageurl, outcontent, contentcodetype, abstract, abstractcodetype,configid, categoryid, host, listurl, believeable, weight)
                self.LOG.print_info("data  :  {}".format(str(title) + str(sourceURL)))
                self.SQL.insert_FSoutsourceingcollection(data, self.LOG)
        except Exception as error:
            self.LOG.print_error("parse_contentTitle error ! {}".format(error))


    def run(self):
        '''
            控制爬虫的启动
        :return:
        '''
        for i in range(12):
            self.LOG.print_info('i : {}'.format(i))
            if i == 0:
                url = 'http://edu.foshan.gov.cn/kx/jjkx/index.html'
                self.LOG.print_info("url : {}".format(url))
                nmb = self.req_fsjyNet(url)
                if nmb ==False:
                    break

            else:
                url = 'http://edu.foshan.gov.cn/kx/jjkx/index_{}.html'.format(i)
                self.LOG.print_info("url : {}".format(url))
                nmb =self.req_fsjyNet(url)
                if nmb ==False:
                    break

            time.sleep(3)

        self.SQL.DBclose()
        print("****************OK*********")




if __name__ == '__main__':
    FS = fsjyNetClass()
    FS.run()



