import logging
import datetime

class logClass(object):
    def __init__(self, spiderName):
        filenane =  spiderName + str(datetime.datetime.now().strftime("%Y-%m-%d")) + '.log'
        self.logger = logging.getLogger(spiderName)
        self.logger.setLevel(level=logging.INFO)
        handler = logging.FileHandler("LOG/" +filenane)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    def print_info(self, text):
        self.logger.info(text)
    def print_debug(self,text):
        self.logger.debug(text)
    def print_warning(self,text):
        self.logger.warning(text)
    def print_error(self, text):
        self.logger.error(text)

class logClass1(object):
    def __init__(self, spiderName):
        pass
    def print_info(self, text):
        print(text)
    def print_debug(self,text):
        print(text)
    def print_warning(self,text):
        print(text)
    def print_error(self, text):
        print(text)

if __name__ == '__main__':
    LOG = logClass1("aa")
    LOG.print_error("dsgdfhdfhgdfh")




