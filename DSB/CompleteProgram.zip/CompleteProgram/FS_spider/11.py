# -*- coding:utf-8 -*-
import requests
from lxml import etree

url = 'http://fsamr.foshan.gov.cn/zwdt/tzgg/201910/t20191016_7595426.html'
headers1 = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36'
}
response = requests.get(url=url, headers=headers1)




print("--------------------------------------")
response.encoding = 'UTF-8-SIG'

response = etree.HTML(response.text)

print("------------------------------------------")
content = response.xpath('//div[@class="TRS_Editor"]')
print(content)
#-------------------------------------------------------------------
if len(content) > 0:
    outcontent = etree.tostring(content[0], encoding="utf-8", pretty_print=True, method="html").decode("utf-8").replace(' ', ' ')
    print(outcontent)





