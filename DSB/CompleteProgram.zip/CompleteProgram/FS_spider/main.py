import os
import time
import sys
import datetime

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(os.path.split(rootPath)[0])

#
# base = datetime.datetime.now()
# while True:
#     new = datetime.datetime.now()
#     print('the  fsamrFoshanGov_spider')
#     os.system("python fsamrFoshanGov_spider.py")
#     print('the  xinhuanet_spider.py')
#     os.system("python xinhuanet_spider.py")
#     print('the fsjyNet_spider.py')
#     os.system("python fsjyNet_spider.py")
#
#     #time.sleep(86400)
#
    

def doSth():
    # 把爬虫程序放在这个类里
    print(datetime.datetime.now())
    print('the  fsamrFoshanGov_spider')
    os.system("python fsamrFoshanGov_spider.py")
    print('the  xinhuanet_spider.py')
    os.system("python xinhuanet_spider.py")
    print('the fsjyNet_spider.py')
    os.system("python fsjyNet_spider.py")


#86400
# 一般网站都是10:00点更新数据，所以每天凌晨一点启动
def main(h=9, m=50):
    while True:
        now = datetime.datetime.now()
        # print(now.hour, now.minute)
        if now.hour == h and now.minute == m:
            doSth()
        # 每隔60秒检测一次
        time.sleep(60)


if __name__ == '__main__':
    main()
