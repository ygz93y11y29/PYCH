# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class CanscrapyItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    D_title = scrapy.Field()
    D_publicationTime = scrapy.Field()
    D_author = scrapy.Field()
    D_content = scrapy.Field()
    encoding = scrapy.Field()
    data_insert = scrapy.Field()
    source = scrapy.Field()
    D_url = scrapy.Field()