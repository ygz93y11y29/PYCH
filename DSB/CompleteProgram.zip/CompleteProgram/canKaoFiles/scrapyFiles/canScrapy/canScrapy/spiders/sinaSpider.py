# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisSpider
import datetime
import time
import logging

import scrapy_redis.dupefilter


class SinaspiderSpider(RedisSpider):
    name = 'sinaSpider'
    allowed_domains = ['mil.news.sina.com.cn']
    # start_urls = ['http://mil.news.sina.com.cn/roll/index.d.html?cid=57918']
    redis_key = 'sinaspiderspider:start_urls'



    def parse(self, response):
            D_urlList = response.xpath('//ul[@class="linkNews"]/li/a/@href').extract()
            D_titleList = response.xpath('//ul[@class="linkNews"]/li/a/text()').extract()

            listData = []
            for i in range(len(D_urlList)):
                data = dict()
                data['D_title'] = D_titleList[i]
                data['D_url'] = D_urlList[i]
                listData.append(data)
                yield scrapy.Request(url=D_urlList[i], callback=self.detailed_parse)


    def detailed_parse(self, response):
        item = dict()
        item['D_title'] = self.remove_n_r(''.join(response.xpath('//title/text()').extract()))
        item['D_publicationTime'] = self.remove_n_r(
            ''.join(response.xpath('//div[@class="post_time_source"]/text()').extract()))
        item['D_author'] = self.remove_n_r(''.join(response.xpath('//a[@id="ne_article_source"]/text()').extract()))
        item['D_content'] = self.remove_n_r(''.join(response.xpath('//div[@id="endText"]').extract()))

        item['D_url'] = response.url
        item['source'] = '新浪'
        item['encoding'] = response.encoding
        item['data_insert'] = datetime.datetime.now()
        time.sleep(2)
        yield item

    def remove_n_r(self, originalStr):
        if originalStr != None:
            originalStr = originalStr.replace('\r\n', '').replace('\n', '').replace('\t', '')
        return originalStr
