# -*- coding: utf-8 -*-
import redis

conn = redis.Redis(host='192.168.10.3',port='6379',password='123456',decode_responses=True,db='15')

conn.lpush('sinaspiderspider:start_urls','http://mil.news.sina.com.cn/roll/index.d.html?cid=57918&page=5')##按照这个格式来存数据的

print(conn.smembers('myspider:start_urls'))