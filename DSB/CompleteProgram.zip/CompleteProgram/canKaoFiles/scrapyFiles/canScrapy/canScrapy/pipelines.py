# -*- coding: utf-8 -*-
import pymssql

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


class CanscrapyPipeline(object):
    def process_item(self, item, spider):
        return item


class SQLServerPipeline(object):
    def __init__(self, host, database, user, password, port):
        self.host = host
        self.database = database
        self.user = user
        self.password = password
        self.port = port

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            host=crawler.settings.get('MYSQL_HOST'),
            database=crawler.settings.get('MYSQL_DATABASE'),
            user=crawler.settings.get('MYSQL_USER'),
            password=crawler.settings.get('MYSQL_USER'),
            port=crawler.settings.get('MYSQL_PORT')
        )

    def open_spider(self, spider):
        # self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8')
        self.db = pymssql.connect(database="RPT_DB_V3", user="rip_conn", password="1234QWER!@#$", host="192.168.9.180",
                                  charset="utf8")
        self.cursor = self.db.cursor()

    def process_item(self, item, spider):
        try:
            D_title = item["D_title"]
            D_publicationTime = item["D_publicationTime"]
            D_author = item["D_author"]
            D_content = item["D_content"]
            encoding = item["encoding"]
            data_insert = item["data_insert"]
            source = item["source"]
            D_url = item["D_url"]

            insert_sql = "INSERT INTO ods_spider_news (source, D_title, D_publicationTime, D_author, D_content, D_url, encoding, data_insert) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
            data = (source, D_title, D_publicationTime, D_author, str(D_content), D_url, encoding, data_insert)
            self.cursor.execute(insert_sql, data)
            self.db.commit()
        except Exception as error:
            print('insert   error ！ -> ', error)
        return item

    def close_spider(self, spider):
        self.db.close()