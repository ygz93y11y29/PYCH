# -*- coding: utf-8 -*-
import redis
from scrapy.dupefilters import BaseDupeFilter
# 类似MD5值的一个数【如果url是一样的那么这个类似md5值的数也是一样的】
from scrapy.utils.request import request_fingerprint

#自定义
class DupFilter(BaseDupeFilter):
    def __init__(self):
        self.conn = redis.Redis(host='192.168.10.3',port=6379, db=15, password='123456')

    def request_seen(self, request):
        """
        检测当前请求是否已经被访问过
        :param request:
        :return: True表示已经访问过；False表示未访问过
        """
        # fid = request_fingerprint(request)
        fid = request.url
        # redis集合
        result = self.conn.sadd('visited_urls', fid)
        if result == 1:
            return False
        return True



# 修改默认配置
#DUPEFILTER_CLASS = 'scrapy.dupefilter.RFPDupeFilter'

# DUPEFILTER_CLASS = 'xxd.translate.DupFilter'



import scrapy_redis.scheduler

