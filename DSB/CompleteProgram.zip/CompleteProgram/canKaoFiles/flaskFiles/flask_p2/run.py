# -*- coding:utf-8 -*-
'''
        启动我们的应用程序
'''

from app_v1 import app


app.run(debug = True)