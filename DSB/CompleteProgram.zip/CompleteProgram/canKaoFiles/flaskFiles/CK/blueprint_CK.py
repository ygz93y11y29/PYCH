# -*- coding:utf-8 -*-


'''
    1.# 将视图中的蓝图对象导入并注册
        from .views.account import account
        app.register_blueprint(account)

    2. # 实例化蓝图
        account = Blueprint('acc', __name__)

'''


