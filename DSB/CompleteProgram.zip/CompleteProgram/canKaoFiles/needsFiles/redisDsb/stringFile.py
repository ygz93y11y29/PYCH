# -*- coding:utf-8 -*-

#String操作，redis中的String在在内存中按照一个name对应一个value来存储。如图：

