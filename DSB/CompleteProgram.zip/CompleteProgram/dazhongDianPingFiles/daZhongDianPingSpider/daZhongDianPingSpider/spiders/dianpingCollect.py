# -*- coding: utf-8 -*-
import scrapy


class DianpingcollectSpider(scrapy.Spider):
    name = 'dianpingCollect'
    allowed_domains = ['www.dianping.com']
    start_urls = []

    def start_requests(self):
        url = 'https://www.dianping.com/search/keyword/92/0_馋小喵三汁焖锅(铜山万达店)'
        headers = {
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',
            'Referer':'https://www.dianping.com/search/keyword/92/0_N%E5%A4%9A%E5%AF%BF%E5%8F%B8%EF%BC%88%E6%96%B0%E5%A4%A9%E5%9C%B0%E5%BA%97%EF%BC%89',
            'Host':'www.dianping.com',
            'Cookie':'s_ViewType=10; _lxsdk_cuid=172592ef35dc8-0e1ab3475cad4b-f7d1d38-13c680-172592ef35dc8; _lxsdk=172592ef35dc8-0e1ab3475cad4b-f7d1d38-13c680-172592ef35dc8; _hc.v=be658794-12e3-3ace-3308-af0d4a993817.1590634149; _dp.ac.v=7a41d3a9-66a6-4c8e-871d-9b12784e2301; ua=dpuser_3968945109; ctu=ad6d8a838697fa88767159f41d5bb9ca0409c6efbae8148eef1160c9af841ae8; fspop=test; cy=92; cye=xuzhou; _lx_utm=utm_source%3DBaidu%26utm_medium%3Dorganic; Hm_lvt_602b80cf8079ae6591966cc70a3940e7=1593417030,1593417071,1593494939,1593568678; dper=66e47d95721fe25faa5e68f2411b831acaf6859755fdd2adb6e8bd267766d870a43f817d7c6b4abc299cf3274ad6f1a60c811a7615706e86945578d0549f0261ec916d59f00a82b1a99fc405b3d5142fae9de8405f2a04f60f276c2f74335ed4; ll=7fd06e815b796be3df069dec7836c3df; uamo=17374479927; dplet=9ef77453ef3028f06c6e1c260b894e20; Hm_lpvt_602b80cf8079ae6591966cc70a3940e7=1593580111; _lxsdk_s=17308c6b23d-a7e-e7b-63c%7C%7C22'
        }
        yield scrapy.Request(url=url, headers=headers, callback=self.parse)

    def parse(self, response):
        # print("**", response.text)
        'operate J_operate Hide'
        shopInfoList = response.xpath('//div[@class="operate J_operate Hide"]')

        for shopInfo in shopInfoList:
            name = shopInfo.xpath('./a[@class="o-favor J_o-favor"]/@data-name').extract_first()
            address = shopInfo.xpath('./a[@class="o-map J_o-map"]/@data-address').extract_first()
            shopid = shopInfo.xpath('./a[@class="o-map J_o-map"]/@data-shopid').extract_first()
            print("*", shopid, name, address)


