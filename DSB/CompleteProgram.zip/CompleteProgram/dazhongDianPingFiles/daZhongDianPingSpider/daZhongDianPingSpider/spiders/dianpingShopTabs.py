# -*- coding: utf-8 -*-
import scrapy


class DianpingshoptabsSpider(scrapy.Spider):
    name = 'dianpingShopTabs'
    allowed_domains = ['www.dianping.com']
    start_urls = []

    def start_requests(self):
        url = 'http://www.dianping.com/ajax/json/shopDynamic/shopTabs?shopId=l4R9NTama5TxZMAd&cityId=92&shopName=%E5%A4%A7%E5%BC%A0%E7%83%99%E9%A6%8D%E6%9D%91&power=5&mainCategoryId=25474&shopType=10&shopCityId=92&_token=eJxVj91ugkAQhd9lrwnssrsUuBOrCSqmKmC08QIQ%2BV1EdytI03fvGu1Fk0nOmTPfJDPf4OoegY0ghAQp4JZegQ2QClUDKEBwOaEWpqaOMTR1UwHJvwxhiBUQX8N3YH8iQqCiv6HDI1nL4JlYEB6UpzUNaXUi68G4EgG5EK2taV3XqcciatqiydTkzDSen1utJmtr6Ucson6%2F90ZHeRKQm8yXm1Krl0YvFX%2B9J3%2BQLC%2ByRrp01vsbTvjltPZ4HMCAi%2BXg9YNf9DM%2FMW%2Bjc7Vj%2B8uOGVlIZ2kzFSy65GFDnYR0dDtOJ862rNiqDS1XQkUU5NN6bpXjukwWwwSjU9xWX%2BGHde8JLoeBxot0j70mK8LxPBObeAWX9chxtvc%2BAD%2B%2FiohtWw%3D%3D&uuid=be658794-12e3-3ace-3308-af0d4a993817.1590634149&platform=1&partner=150&optimusCode=10&originUrl=http%3A%2F%2Fwww.dianping.com%2Fshop%2Fl4R9NTama5TxZMAd'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',
            'Referer': 'http://www.dianping.com/shop/l4R9NTama5TxZMAd',
            'Host': 'www.dianping.com',
            'Cookie': 's_ViewType=10; _lxsdk_cuid=172592ef35dc8-0e1ab3475cad4b-f7d1d38-13c680-172592ef35dc8; _lxsdk=172592ef35dc8-0e1ab3475cad4b-f7d1d38-13c680-172592ef35dc8; _hc.v=be658794-12e3-3ace-3308-af0d4a993817.1590634149; _dp.ac.v=7a41d3a9-66a6-4c8e-871d-9b12784e2301; ua=dpuser_3968945109; ctu=ad6d8a838697fa88767159f41d5bb9ca0409c6efbae8148eef1160c9af841ae8; fspop=test; cy=92; cye=xuzhou; _lx_utm=utm_source%3DBaidu%26utm_medium%3Dorganic; Hm_lvt_602b80cf8079ae6591966cc70a3940e7=1593417030,1593417071,1593494939,1593568678; dper=66e47d95721fe25faa5e68f2411b831acaf6859755fdd2adb6e8bd267766d870a43f817d7c6b4abc299cf3274ad6f1a60c811a7615706e86945578d0549f0261ec916d59f00a82b1a99fc405b3d5142fae9de8405f2a04f60f276c2f74335ed4; ll=7fd06e815b796be3df069dec7836c3df; uamo=17374479927; dplet=407562292f19f07625c522137fefaa44; Hm_lpvt_602b80cf8079ae6591966cc70a3940e7=1593582311; _lxsdk_s=17308c6b23d-a7e-e7b-63c%7C%7C82'
        }


    def parse(self, response):
        pass
